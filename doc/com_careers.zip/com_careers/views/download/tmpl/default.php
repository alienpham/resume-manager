<? 

$temp_path = $_SERVER['DOCUMENT_ROOT'].'/vipsearchweb/components/com_careers/views/TemplateExportJD.dot';
$download_path = $_SERVER['DOCUMENT_ROOT'].'/vipsearchweb/components/com_careers/views/';
 
$vacancy_id	= JRequest::getVar('vacancy_id', 0, '', 'int');
//$member_id  = JRequest::getVar('member_id', 0, '', 'int');
$member_id = 2;


try	{
	com_load_typelib('Word.Application');
	$word = new COM("Word.Application") or die("Cannot start MS Word");
	//$word = new COM("Word.Application", NULL, 65001) or die("Cannot start MS Word");
	$word->Application->visible = False ;
	$word->Documents->Open(realpath($temp_path));
	//$word->Documents->Open(realpath($invoice),False,False,False,'','',False,'','',1,65001);
	//$word->ActiveDocument->TextEncoding = 65001;

}catch ( Exception $e ) {
	echo $e;
}

//echo 'test:'.$temp_path;
/*$model = $this->getModel('Mysavejob' );

if(!$model->checkMySaveJob($member_id, $vacancy_id)){
if(!$model->saveJob($member_id, $vacancy_id)) {
$msg = JText::_( 'Error: One or more job Could not be saved' );
} else {
$msg = JText::_( 'My save job had been done.' );
}
}*/
//$this->setRedirect( 'index.php?option=com_careers&view=mysavejob&Itemid=87&lang=en', $msg );

//$careersViewJobDetail = new CareersViewJobDetail();
//echo 'salary: '.$careersViewJobDetail->salary;

//echo $careersViewJobDetail->row->title;




$file_name ='test.doc';
$filename = $download_path.$file_name;
try	{
	//$word->Application->ActiveDocument->SaveEncoding = 'msoEncodingUTF8';//msoEncodingWestern msoEncodingUTF8
	$word->Application->ActiveDocument->Saved=True;
	$word->Documents[1]->SaveAs($filename);
	//$word->Documents[1]->SaveAs($file_name,1,False,'',False,'',False,True,False,False,False,65001);
	//expression.SaveAs(FileName, FileFormat, LockComments, Password, AddToRecentFiles, WritePassword, ReadOnlyRecommended, EmbedTrueTypeFonts, SaveNativePictureFormat, SaveFormsData, SaveAsAOCELetter, Encoding, InsertLineBreaks, AllowSubstitutions, LineEnding, AddBiDiMarks)

}catch ( Exception $e ) {
	echo $e;
}

//while($word->Application->BackgroundPrintingStatus>0){sleep (1);}
//$word->Visible = 1;
//echo 'Created word successull.';

// close the application and release the COM object
// wait to quit
try{
	$word->ActiveDocument->Close();
	$word->Quit( );
	//$word->Release( );
	$word = null;

} catch ( Exception $e ) {
	echo $e;
}


/*header('Content-Description: File Transfer');
 header("Content-Type: application/msword");
 header('Content-Type: application/octet-stream');
 header('Content-Type: application/msword; charset=utf-8');

 //header('Content-Disposition: attachment; filename='.$file_name);
 header('Content-Transfer-Encoding: UTF-8');
 //header('Expires: 0');
 header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
 //header('Pragma: public');
 ob_clean();

 readfile($filename);
 flush();*/
//echo $download_path.$file_name;

$file_path = 'http://'.$_SERVER['HTTP_HOST']. '/vipsearchweb/components/com_careers/views/'.$file_name;
$this->setRedirect($file_path);

echo $file_path;

?>