<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewMysavejob extends JView
{
	function display($tpl = null)
	{
		global $mainframe;

		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');
		$error1 = '';
		$error2 = '';
		$_SESSION['url_redirect'] = $_SERVER['REQUEST_URI'];
		
		// Get the page/component configuration
		$params = &$mainframe->getParams();
		$this->assignRef('params',	$params);
		$pagination	= &$this->get('pagination');
		$model = &$this->getModel('mysavejob');

		if($member_id){
			$items = $this->get('Data');
			$this->assignRef( 'items', $items );

			if(count($items)==0)
			$error2 = JText::_('NO_DATA_FOUND_MY_SAVE_JOB');
		}else{
			$error1 = JText::_('REQUEST_LOGIN_DISPLAY_MY_SAVE_JOB');
			$link = JRoute::_('index.php?option=com_members&view=login&Itemid=133');
			$mainframe->redirect($link , $error1 );
		}

		$this->assignRef('pagination',  $pagination);
		$this->assignRef('error1',  $error1);
		$this->assignRef('error2',  $error2);

		parent::display($tpl);
	}
}
?>
