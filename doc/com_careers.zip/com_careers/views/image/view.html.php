<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewImage extends JView
{
	function display($tpl = null)
	{
		$images2 = array('logo_content'=>'',
						'logo_name'=>'',
						'logo_width'=>'',
						'logo_height'=>'',
						'logo_file_type'=>''							
						);
		$vacancy_id=JRequest::getVar("vacancy_id");
		$db =& JFactory::getDBO();
		$query="SELECT c.* FROM vip_company_profile c, vip_vacancy v
				WHERE c.company_profile_id=v.company_profile_id AND v.vacancy_id='".$vacancy_id."'";
		
 		$db->setQuery($query);
 		$rows = $db->loadObject();
 		//echo $rows->logo_content ;
 		$this->images2['logo_content'] = $rows->logo_content;
 		$this->images2['logo_name'] = $rows->logo_name;
 		//$this->images2['logo_name'] = 'sdfsdfsdfsdf';
 		$this->images2['logo_width'] = $rows->logo_width;
 		$this->images2['logo_height'] = $rows->logo_height;
 		$this->images2['logo_file_type'] = $rows->logo_file_type;
 		
 		$this->images = $images2;
 		
 		
 		echo header("Content-type:".$this->images2['logo_file_type']);
 		
 		//echo '<img  src="';
 		//echo $this->images2['logo_file_type'];
		//echo $this->images2['logo_name'];
	  	echo $this->images2['logo_content'];
	  	
	  	//echo '" >';
		
		
		
		
		//$this->assignRef('image',  $image2);

		parent::display($tpl);
	}
}
?>
