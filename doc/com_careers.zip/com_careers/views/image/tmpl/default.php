<?php
//echo header("Content-type:".$this->images['logo_file_type']);
//echo $this->images['logo_name'];
//print_r($this->images);
//echo $this->getImages();
//echo $this->images['logo_content'];

//<img style="float:left; margin-right:8px; margin-top:2px;"  src= 	   name="test" width="218" height="107" >
?>


