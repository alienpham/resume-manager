<?php defined('_JEXEC') or die('Restricted access');?>
<?php if(@$this->row->vacancy_status=="Active Public") {?>

<p class="title_info"><?php echo $this->row->title;?></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td height="25" colspan="2"><a href="#" onClick="javascript:history.back(-1)">Back to search results</a></td>
		<td colspan="2" align="right">
			<a rel="nofollow" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;"	title="Print"
			href="index.php?option=com_careers&view=jobprint&vacancy_id=<?php echo $this->row->vacancy_id?>&Itemid=7&tmpl=component&print=1&layout=default&page=&lang=en">
				<?php echo JText::_('Print version'); ?>
			</a>
		</td>
	</tr>
	<tr>
		<td height="2" colspan="4" bgcolor="#CCCCCC"></td>
	</tr>
	<tr>
		<td height="8" colspan="4"></td>
	</tr>
	<tr>
		<td width="20%" height="20"><strong>Job Code:</strong></td>
		<td width="31%"><?php echo $this->row->vacancy_code;?></td>
		<td width="28%" align="right"><strong>Posted:</strong></td>
		<td width="21%" align="right"><?php echo date("M d, Y",strtotime($this->row->posted_date));?></td>
	</tr>
	<tr>
		<td colspan="4" height="9" background="images/line.jpg" /></td>
	</tr>
	<tr>
		<td height="20"><strong>Salary:</strong></td>
		<td><?php echo $this->salary;?></td>
	    <td align="right"><strong>Closed Date:</strong></td>
	    <td align="right"><?php if($this->row->closed_date!=null) echo date("M d, Y",strtotime($this->row->closed_date)); else echo "ASAP";?></td>
	</tr>
	<tr>
		<td colspan="4" height="9" background="images/line.jpg" /></td>
	</tr>
	<tr>
		<td height="20"><strong>Location:</strong></td>
		<td colspan="3"><?php echo $this->listsLocation;?></td>
	</tr>
	<tr>
		<td colspan="4" height="9" background="images/line.jpg" /></td>
	</tr>
	<tr>
		<td height="20"><strong>Function:</strong></td>
		<td colspan="3"><?php echo $this->listsFunction;?></td>
	</tr>
	<tr>
		<td height="8" colspan="4"></td>
	</tr>
	<tr>
		<td height="2" colspan="4" bgcolor="#CCCCCC"></td>
	</tr>
</table>
<p align="justify"><strong>COMPANY INFORMATION</strong></p>
<img
	style="float: left; margin-right: 10px; margin-top: 2px; margin-bottom:5px"
	src="<? echo JURI::base().'components/com_careers/image.php?vacancy_id='.$this->row->vacancy_id ?>">

<?php echo nl2br($this->company_profile);?>
<p align="justify"><strong>RESPONSIBILITIES</strong></p>
<?php echo nl2br($this->row->description);?>
<p align="justify"><strong>REQUIREMENTS</strong></p>
<p><?php echo nl2br($this->row->requirement);?></p>
<form method="post" name="login" action="index.php" enctype="multipart/form-data" >
<div style="background-color:#f2f2f2; padding: 5px 10px 0px 10px">
	<p><a name="apply" />	<strong>APPLY NOW </strong></p>
	<?php 
	$session =& JFactory::getSession();
	$member_id 	= $session->get('member_id');
	$full_name 	= $session->get('name');
	$email 		= $session->get('email');
	@$messages 	= $mainframe->getMessageQueue();
 	@$num 		= intval($messages[0]['message']);
 	@$error 	= substr($messages[0]['message'], 1, 100);
	
	//if(@$num == 3 && $error) echo '<p style="color:blue">'.@$error.'<p>';
	
 	if( $member_id ){
		$db = JFactory::getDBO();
		$query	= 'SELECT * FROM #__resume WHERE member_id = '.$member_id;
		$db->setQuery($query);
		$resume = $db->loadObject();
		
		@$updatedDate = explode('-', substr($resume->updated_date, 0, 10));
		@$date = date('M j, Y', mktime(0,0,0, $updatedDate[1], $updatedDate[2], $updatedDate[0]));
	?>
		<div style="width:100px; float:left">
			<span style="display:block; float:left; height:40px;"><input type="radio" name="chkresume" value="haslogin" <?php if(@$num != 2) echo 'checked="checked"'?> /></span>
			<span><strong>&nbsp;Option 1 - With Stored Resume</strong></span>
		</div>
		<div style="width:354px; float:left;">
			<?php 
			if (@$resume->file_type){
				if (@$resume->file_type == 'application/pdf'){
					echo '<img src="images/icon_pdf_l.png" align="left" hspace="10" vspace="2" />';
				}else{	
					echo '<img src="images/icon_word_l.png" align="left" hspace="10" vspace="2" />';
				}
				?>
				
				<a href="index.php?option=com_members&task=download&resumeid=<?php echo $resume->resume_id ?>" target="_blank">
				<strong><?php echo @$resume->name; ?></strong></a>
				<br /><font class="small"><?php echo JText::_('Updated').':'.$date.' |';?></font>
		<?php	
			}else{
				echo '<strong>Resume not found </strong>';		
			}		
		?>			

			<a href="index.php?option=com_members&view=update&Itemid=85"><?php echo JText::_('Update Resume ') ?></a>
			
		</div>
		<div style="clear:both"></div>
	<?php }else{?>
		<div>
			<input type="radio" name="chkresume" value="haslogin" <?php if(@$num != 2) echo 'checked="checked"'?> />
			<strong>&nbsp;Option 1 - With Stored Resume</strong> (Please log in to retrieve):
		</div>
		<div style="padding-left:24px">
		<?php	
			if(@$num == 1 && $error) echo '<p class="note_start">'.@$error.'<p>';
		?>
			<?php if(@$_SESSION['cache_email1'] && $_SESSION['cache_email1'] != 'Login Email'){ ?>
			<div style="padding-top:5px"><input name="email" type="text" style="width: 200px" value="<?php echo $_SESSION['cache_email1'];  ?>" /></div>				
			<?php }else{ ?>
			<div style="padding-top:5px"><input name="email" type="text" style="width: 200px" onfocus="if(this.value=='Login Email') this.value='';" onblur="if(this.value=='') this.value='Login Email';" value="Login Email" /></div>
			<?php } 
			unset($_SESSION['cache_email1']);
			?>
			<div style="padding-top:5px"><input name="password" type="password" style="width: 200px" onfocus="if(this.value=='Password') this.value='';" onblur="if(this.value=='') this.value='Password';" value="Password" /></div>
			<div style="padding-top:5px"><input type="submit" name="apply" value="Login" /></div>
		</div>
	<?php } ?>	 
	<div style="padding:10px"><hr /></div>
	<div>
		<input type="radio" name="chkresume" value="nologin" <?php if(@$num == 2) echo 'checked="checked"'?> />
		<strong>&nbsp;Option 2 - With Attached Resume</strong>:
	</div>
	<div style="padding-left:24px">
	<?php	
		if(@$num == 2 && $error) echo '<p class="note_start">'.@$error.'<p>';
	?>
		<?php if(@$_SESSION['cache_name']){ ?>
		<div style="padding-top:5px"><input name="name" type="text"	style="width: 200px" value="<?php echo $_SESSION['cache_name']; ?>" /></div>
		<?php }else{ ?>
		<div style="padding-top:5px"><input name="name" type="text"	style="width: 200px" onfocus="if(this.value=='Your fullname') this.value='';" onblur="if(this.value=='') this.value='Your fullname';" value="<?php if($full_name)echo $full_name; else  echo 'Your fullname';?>" /></div>
		<?php } ?>
		
		<?php if(@$_SESSION['cache_email2'] && trim($_SESSION['cache_email2']) != 'Your email'){ ?>
		<div style="padding-top:5px"><input name="youremail" type="text" style="width: 200px" value="<?php echo $_SESSION['cache_email2'];?>" /></div>
		<?php }else{ ?>
		<div style="padding-top:5px"><input name="youremail" type="text" style="width: 200px" onfocus="if(this.value=='Your email') this.value='';" onblur="if(this.value=='') this.value='Your email';" value="<?php if($email)echo $email; else  echo 'Your email';?>" /></div>
		<?php }
		 
		unset($_SESSION['cache_email2']);
		unset($_SESSION['cache_name']);
		?>
		
		<div style="padding-top:5px"><input name="file" type="file" style="width: 290px" size="30" onChange="document.login.filename.value=this.value;"/> <input type="hidden" name="filename" value=""></div>
		<p>Please attach your resume as a Microsoft Word (.doc) or Adobe Arobat (.pdf) document. All other formats will be rejected.</p>
		<div><input type="submit" name="apply" value="Submit" /></div>
	</div>
	<div style="padding:10px"><hr /></div>
	<div>Alternatively, you can send your application to <a href="mailto:resume@VIPsearch.com">resume@VIPsearch.com</a></div>
	<br />
</div>
<input type="hidden" name="option" value="com_careers" />
<input type="hidden" name="view" value="jobdetail" />
<input type="hidden" name="task" value="login" />
<input type="hidden" name="vacancy_id" value="<?php echo $this->row->vacancy_id ?>" />
</form>		
<br /><br />
<?php } else {?>
<p class="title_info">Job Not Found</p>
<p>
	Sorry. It seems that this position is already
	closed. Please try &quot;Search&quot; feature to search for similar
	jobs. (Click &quot;Senior & Executive Jobs&quot; on the Left Menu).
</p>
<?php }?>