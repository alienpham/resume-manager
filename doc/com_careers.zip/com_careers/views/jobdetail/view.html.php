<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewJobDetail extends JView
{
	function display($tpl = null)
	{
		global $mainframe;
		$Itemid		= JRequest::getVar("Itemid");
		$vacancy_id	= JRequest::getInt("vacancy_id", 0);
		$option		= JRequest::getVar("option");
		$view		= JRequest::getVar("view");
		$document	= &JFactory::getDocument();

//setMetaData description and keywords
$document->setMetaData('description', 'VIPsearch provides thousands of senior and top management positions across 5 industries: Consuming, Finance & Banking, ICT, Industrial and Services.', 'http-equiv');
	
//echo "HERE";
		$_SESSION['url_redirect'] = $_SERVER['REQUEST_URI'];
		
		if( $vacancy_id ){
			$db =& JFactory::getDBO();
			
			$query="UPDATE #__vacancy SET view_count=view_count+1 WHERE vacancy_id=".$vacancy_id."";
			$db->setQuery($query);
			if (!$db->query()) {
				JError::raiseError( 500, $db->getErrorMsg() );
				return false;
			}
			$query="SELECT * FROM #__vacancy WHERE vacancy_id='".$vacancy_id."'";
			
	 		$db->setQuery($query);
	 		$rows = $db->loadObject();
			//print_r( $rows );
	 		$listsLocation_id= str_replace("|",",",CareersViewJobDetail::getListName("#__vacancy_has_location", "vacancy_id='".$vacancy_id."'","city_id"));
	 		if($listsLocation_id=="")
	 			$listsLocation_id="''";
	 		$listsLocation= CareersViewJobDetail::getListName("#__city_lookup", "city_id in(".$listsLocation_id.")","name");
	 		
	 		$listsFunction_id= str_replace("|",",",CareersViewJobDetail::getListName("#__vacancy_has_function", "vacancy_id='".$vacancy_id."'","function_id"));
	 		if($listsFunction_id=="")
	 			$listsFunction_id="''";
	 		$listsFuntion= CareersViewJobDetail::getListName("#__function_lookup", "function_id in(".$listsFunction_id.")","name");
	 		
	 		
			// Get the page/component configuration
			$params = &$mainframe->getParams();
			$company_profile= CareersViewJobDetail::getListName("#__company_profile", "company_profile_id ='".$rows->company_profile_id."'","introduction");
			if($rows->salary_min==$rows->salary_max && $rows->salary_max>0)
				$salary="Around $".$rows->salary_max;
			else
			if($rows->salary_min==$rows->salary_max && $rows->salary_max==0)
				$salary="Negotiable";
			else
			if($rows->salary_min>0 && $rows->salary_max==0)
				$salary="Above $".$rows->salary_min;
			else			
			if($rows->salary_min==0 && $rows->salary_max>0)
				$salary="Up to $".$rows->salary_max;
			else
				$salary="$".$rows->salary_min. " - $".$rows->salary_max;
			
			$this->assignRef('params',$params);
			$this->assignRef('salary',$salary);
			$this->assignRef('company_profile',$company_profile);
			$this->assignRef('listsLocation',$listsLocation);
			$this->assignRef('listsFunction',$listsFuntion);
			$this->assignRef('row',$rows);
			$document->setMetaData('keywords', $rows->title.', Vipsearch, VIPsearch, vipsearch, vip seach, executive search, executive search firms, international executive search, retained executive search firm, retained executive search firms, top executive search firm, executive search consultants, executive search recruitment, retained executive search, top executive search firms, executive jobs, search executive jobs, executive job search, executive positions, executive head hunter, executive job, executive headhunters, executive placement, executive recruiters, executive recruitment, executive head hunters, executive headhunter, executive recruiter, executive recruiting, executive research, executive, executive employment, executive careers, job search, job vacancies, recruitment agencies, recruitment, recruitment agency, recruiters, employment, employment agencies, employment agency, head hunter, head hunters, headhunter, headhunters, recruiting agency, recruiter
', 'http-equiv');
			$document->setTitle( "VIPsearch - ".$rows->title." | Find Talents. Add Values." );
		}	
		/*if($rows->vacancy_status=="Closed" || $rows->vacancy_status=="")
			$this->assignRef('show',"0");
		else
			$this->assignRef('show',"1");*/
		parent::display($tpl);
	}
	
	function getListName($table,$condition,$field)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT distinct($field) as $field FROM $table WHERE $condition ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		$num = 0;
		$str = "";
		foreach( $rows as $row )
		{
			if ( $num==0 )
				$str = $row->$field;
			else
				$str.= " | ".$row->$field;
			$num++;
		}
		return $str;
	}
	
	

}
?>
