<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewComfirmation extends JView
{
	function display($tpl = null)
	{
		global $mainframe;
		ini_set("magic_quotes_sybase",0);
		$message = JRequest::getVar('mess');
		if($message=="")
		{
		//echo"HERE";
			$messages 	= $mainframe->getMessageQueue();
		
 		$message 	= @$messages[0]['message'];
		}
 		$case = JRequest::getVar('case');
 		$app			=& JFactory::getApplication();
 		$vacancy_id = JRequest::getVar('vacancy_id');
 		//$file = $_POST["file"];
 		//echo $file[0];
 		//echo phpinfo();;
 		//exit;
		echo "<div class='contentheading'> COMFIRMATION </div>";
		
		echo "<p>$message</p>";
		$link_view_job = @$_SESSION['link_viewjob'];
		$link = $_SESSION['link'];
		$file=$_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".str_replace(" ","_",@$_SESSION['file_name']);
		if(is_file($file))
		{
			$f = fopen($file, "rb");
			$contents = @fread($f, filesize($file));
			$contents = addslashes($contents);
			//unlink($file);
			//echo "HERE";
		}
		else
			$contents="";
		if($case!="")
		{
			echo "<form name='confirm' method='post' enctype='multipart/form-data'>";
			echo "<input type='hidden' name='case' value='$case'>";
			echo "<input type='hidden' name='vacancy_id' value='$vacancy_id'>";
			
			echo "<input type='submit' name='redirect' value=' OK ' >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			echo "<input type='submit' name='redirect' value='CANCEL' >";
			
			//echo "<input type='hidden' name='contents' value=\"".$file."\">";
			//echo '<textarea name="contents" cols="" rows="" style="visibility:hidden ">'.$contents.'</textarea>';
			echo "</form>";
		}
		else
		{
			echo "<input type='button' name='redirect' value=' OK ' onClick=\"window.location='$link'\">";
			unset($_SESSION['link']);
		}
		
		if(isset($_POST['case']))
		{
			$db =& Jfactory::getDBO();
			$query	= 'SELECT v.*, c.full_name, c.email FROM #__vacancy as v INNER JOIN #__consultants as c '; 
			$query	.= 'ON v.consultant_id = c.consultant_id WHERE vacancy_id = '.$_POST['vacancy_id'];
			$db->setQuery($query);
			$vacancy = $db->loadObject();
			$session =& JFactory::getSession();
			$message 	= $_SESSION['message_mail'];
				
			$subject 	= $_SESSION['subject_mail'];
			
			$mailfrom 	= $mainframe->getCfg('mailfrom');
			$fromname 	= $mainframe->getCfg('fromname');		
			
			if($_POST['case']==1 && trim($_POST["redirect"])=="OK")
			{
				$sql = "SELECT * FROM #__resume WHERE member_id='$member_id'";
				$db->setQuery($sql);
				$rs_file=$db->loadObject();
				
				$f=fopen($_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".$rs_file->name, "w");
				fwrite($f,$rs_file->file_content);
				$file=$_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".$rs_file->name;
				
				JUtility::sendMail($mailfrom, $fromname, $vacancy->email, $subject, $message, 0, "resume@vipsearch.com", null, $file, $session->get('email'), $vacancy->full_name);
				$query = "UPDATE #__members_has_application SET applied_date='".date('Y-m-d H:i:s')."' WHERE vacancy_id='$vacancy_id' AND member_id='".$session->get('member_id')."'";
			
				$db->setQuery($query);
				if(!$db->query()) {
					return JError::raiseWarning( 500, $db->getError() );
				}
				
				$query="UPDATE #__vacancy SET applied_count=applied_count+1 WHERE vacancy_id=".$vacancy_id."";
				$db->setQuery($query);
				if (!$db->query()) {
					JError::raiseError( 500, $db->getErrorMsg() );
					return false;
				}
				
				unset($_SESSION['link']);
				unset($_SESSION['link_viewjob']);
				
				//$mainframe->redirect($link);
			}
			else
			if($_POST['case']==2 && trim($_POST["redirect"])=="OK")
			{		
				$query="UPDATE #__non_members SET full_name='".$_SESSION['full_name']."',file_name='".$_SESSION['file_name']."', file_type='".$_SESSION['file_type']."', file_size='".$_SESSION['file_size']."', file_content='".$contents."', applied_date='".date('Y-m-d H:i:s')."'
						WHERE email='".$_SESSION['youremail']."' AND vacancy_code='$vacancy->vacancy_code'";

				$db->setQuery($query);
				if(!$db->query()) {
					return JError::raiseWarning( 500, $db->getError() );
				}
				if($session->get('member_id'))
				{
					$sql_apply="SELECT * FROM #__members_has_application WHERE vacancy_id='$vacancy->vacancy_id' AND member_id='".$session->get('member_id')."'";
					$db->setQuery($sql_apply);
					$row_apply=$db->loadObject();
					if($row_apply->id!="")
					{
						$sql="UPDATE #__members_has_application SET applied_date='".date('Y-m-d H:i:s')."' WHERE id='$row_apply->id'";
						$db->setQuery($sql);
						if(!$db->query()) {
							return JError::raiseWarning( 500, $db->getError() );
						}
					}
					else
					{
						$sql="INSERT INTO #__members_has_application(member_id,vacancy_id,applied_date) VALUES('".$session->get('member_id')."','$vacancy->vacancy_id','".date('Y-m-d H:i:s')."')";
						$db->setQuery($sql);
						if(!$db->query()) {
							return JError::raiseWarning( 500, $db->getError() );
						}
					}
				}
				//echo  $session->get('email');
				JUtility::sendMail($mailfrom, $fromname, $vacancy->email, $subject, $message, 0, "resume@vipsearch.com", null, $file, $_SESSION['youremail'], $vacancy->full_name);
				
				$query="UPDATE #__vacancy SET applied_count=applied_count+1 WHERE vacancy_id=".$vacancy->vacancy_id."";
				$db->setQuery($query);
				if (!$db->query()) {
					JError::raiseError( 500, $db->getErrorMsg() );
					return false;
				}
				
				unset($_SESSION['link']);
				unset($_SESSION['link_viewjob']);
				unset($_SESSION['youremail']);
				unset($_SESSION['full_name']);
				unset($_SESSION['file_name']);
				unset($_SESSION['file_name']);
				unset($_SESSION['file_type']);
				unset($_SESSION['file_size']);
				
				//$mainframe->redirect($link);
			}
			unlink($file);
			if($_POST["redirect"]=="CANCEL")
				$mainframe->redirect($link_view_job);
			else
				$mainframe->redirect($link);
		}
		
	}
}
?>
