<?php defined('_JEXEC') or die('Restricted access');?>
<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>

<div
	class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
<?php echo $this->escape($this->params->get('page_title')); ?></div>
<?php endif; ?>
<form action="index.php" method="post" name="myApplicationForm">
<div>
<p>Below are your applications in the last 3 months.</p>
<?php
 	if(@$this->error1){
		echo '<p class="note_start"">'.$this->error1;'</p>';
	}
	$messages = $mainframe->getMessageQueue();
	if(@$messages[0]['message'])
		echo '<p class="message">'.@$messages[0]['message'].'<p>';
?>

<table width="650" cellpadding="0" cellspacing="0" border="0" class="adminlist">
	<thead>
		<tr>
		<!-- 
			<th width="21"><?php echo JText::_( 'ID' ); ?></th>
		 -->	
			<th width="269" align="left" nowrap="nowrap" height="25"><?php echo JText::_('Position'); ?></th>
			<th width="81" align="left" nowrap="nowrap"><?php echo JText::_('Applied Date'); ?></th>
			<th width="247" align="right" nowrap="nowrap"><?php echo JText::_('Consultant in Charge'); ?></th>
			<th width="43" align="center" nowrap="nowrap"><?php echo JText::_('Remove'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="5">
			<?php
			 if(@$this->error2){
					echo '<p class="note_start"">'.$this->error2;'</p>';
				} 
			echo $this->pagination->getPagesLinks(); 
			?></td>
		</tr>
	</tfoot>
<?php if( count( $this->items )) : ?>	 
	<tbody>
<?php 
	$k = 1; 
	foreach( $this->items as $item ) : 
	
	$link 		= JRoute::_( 'index.php?option=com_careers&task=removemyapplication&id='. $item->id );
	$city = JCareer::lookupCityVacancyHasLocation($item->vacancy_id);
	$vacancyStatus = JCareer::getVacancyStatus($item->vacancy_id);
	$linkjob = JRoute::_('index.php?option=com_careers&view=jobdetail&vacancy_id='.$item->vacancy_id.'&Itemid=132');
	$k = 1 - $k;
?>
	
		<tr class="<?php echo "row$k"; ?>">
			<td align="left" >
		<?php
			if($vacancyStatus=='Active Public'){
				echo '<a href="'.$linkjob.'">'. $item->title . ', '.$city.'</a>';
			}else{
				echo $item->title . ', '.$city.'  <font color="#FF0000">[close]</font>';
			}
		?>			  
			</td>
			<td align="left" ><?php echo date('M d, Y',strtotime($item->applied_date)); ?></td>
			<td align="right" ><?php echo $item->prefix_name . $item->full_name .', '.$item->office_phone ?></td>
			<td align="center" >
			<a href="<?php echo $link; ?>" onclick="return confirm('Are you sure you want to delete?')"><img alt="Delete" src="images/delete_item.png" border="0" /></a> 
			</td>
		</tr>
	 <?php endforeach; ?>
	</tbody>
<?php endif; ?>	
</table>

<table width="700" border="0" cellpadding="0" cellspacing="0" >
				<tr>
					<td height="30" colspan="3" >&nbsp;</td>
				</tr>
				<tr>
					<td width="56%" ></td>
					<td width="43%" height="30" align="left" >
					<p><strong>Note: </strong>You should have received an confirmation
					email after you applied for a job. Your applicationwill be
					carefully considered, and if matching, our consultant will contact
					you directly.</p>
					<p>Should you have any question regarding the position or the
					application process, please kindly contact the respective
					consultant in charge above.</p>
					</td>
					<td width="1%"></td>
				</tr>
			</table>
</div>
<input type="hidden" name="option" value="com_careers" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
</form>
