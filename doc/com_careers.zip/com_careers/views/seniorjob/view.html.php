<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewSeniorJob extends JView
{	
function display($tpl = null)
	{
		global $mainframe;
		$Itemid 		= JRequest::getVar("Itemid");
		$listFunctionID	= JRequest::getVar("listFunctionId");
		$listLocationId	= JRequest::getVar("listLocationId");
		$page			= JRequest::getVar("page");
		$vacancy_id		= JRequest::getVar("vacancy_id");
		$industry_id	= JRequest::getVar("industry_id");
		$title			= JRequest::getVar("title");
		$salary_range_id= JRequest::getVar("salary_range_id");
		$db 			=& JFactory::getDBO();
		$db1 			=& JFactory::getDBO();

		$_SESSION['url_redirect'] = $_SERVER['REQUEST_URI'];
		$condition=" a.vacancy_id=b.vacancy_id AND a.vacancy_id=c.vacancy_id AND d.company_profile_id=a.company_profile_id AND e.industry_id=d.industry_id AND a.vacancy_status='Active Public'";
		
		// Create condition
		// Industry Condition
		if ($industry_id!=0 && $industry_id!="")
			$condition.=" AND e.parent_industry_id ='$industry_id'";
		if ($listFunctionID!="")
			$condition.=" AND b.function_id IN($listFunctionID)";
		if($listLocationId!="")
			$condition.=" AND c.city_id IN($listLocationId)";
		
		// Salary Condition
		if ($salary_range_id!=0 && $salary_range_id!="")
		{
			if ($salary_range_id==2)
				$condition.=" AND ((salary_min<=1000 AND salary_min is not null) OR  (salary_max<=1000 AND salary_max is not null))";
			else
			if ($salary_range_id==3)
			{
				$condition.=" AND ((salary_min>=1000  AND salary_min<=2000 AND salary_min is not null) OR  (salary_max>=1000 AND salary_max<=2000 AND salary_max is not null) OR (salary_min>=1000 AND salary_max<=2000))";
			}
			else
			if ($salary_range_id==4)
			{
				$condition.=" AND ((salary_min>=2000  AND salary_min<=3000 AND salary_min is not null) OR  (salary_max>=2000 AND salary_max<=3000 AND salary_max is not null) OR (salary_min>=2000 AND salary_max<=3000))";
			}
			else
			if ($salary_range_id==5)
			{
				$condition.=" AND ((salary_min>=3000 AND salary_min is not null) OR  (salary_max>=3000 AND salary_max is not null))";
			}
			else
				$condition.=" AND ( salary_min is null OR salary_max is null )";
		}
			
		if($title!="" && $title!="Please enter...")
		{
			$str_title=trim($title);
			if ($str_title[0]==$str_title[strlen($str_title)-1] && $str_title[0]=='"')
			{
				$condition.=" AND title= '".trim($str_title,'"')."'";
			}
			else
			{
				$str_title=trim($str_title,'"');
				$str_title=trim($str_title,'+');
				$str_title=trim($str_title,'"');
				$str_title=str_replace(" + ","+",$str_title);
				$str_title=str_replace("+ ","+",$str_title);
				$str_title=str_replace(" +","+",$str_title);
				$arr1=explode(" ",$str_title);
				$num=0;
				$num1=0;
				$condtion1="";
				$condition3="";
				for ($k=0; $k<count($arr1);$k++)
				{
					$str=trim($arr1[$k],"+");
					$tmp=explode("+",$str);
					if (count($tmp)==1)
					{
						if ($num==0)
							$condition1=" title like '%".str_replace("'","\'",$arr1[$k])."%'";
						else
							$condition1.=" OR title like '%".str_replace("'","\'",$arr1[$k])."%'";
						$num++;
					}
					else
					{
						for($l=0;$l<count($tmp);$l++)
						{
							if ($l==0)
								$condition2=" title like '%".str_replace("'","\'",$tmp[$l])."%'";
							else
								$condition2.=" AND title like '%".str_replace("'","\'",$tmp[$l])."%'";
						}
						if ($num1==0)
							$condition3="(".$condition2.")";
						else
							$condition3.=" OR (".$condition2.")";
						$num1++;
					}
				}
				
				if ($condition1!="" && $condition3!="")
				{
					$condition.=" AND ((".$condition1.") OR (".$condition3."))";
				}
				else
				if ($condition1!="")
					$condition.=" AND (".$condition1.")";
				else
					$condition.=" AND (".$condition3.")";
			}
			//$condition.=$title;
		}
		else
			$title="Please enter...";
		
 		// GET RESULT SEARCH JOB
		$query="SELECT distinct a.vacancy_id, vacancy_code, title, salary_min, salary_max, posted_date 
				FROM #__vacancy a, #__vacancy_has_function b, #__vacancy_has_location c, #__company_profile d, #__industry_lookup e
				WHERE $condition ORDER BY posted_date DESC, a.vacancy_id DESC";
		//echo $condition;
		if ($page=="" || $page==0)
			$page=1;
		//echo ($page-1)*1;
		//echo "Page:".$page;
 		$db->setQuery($query, ($page-1)*20 , 20);
 		$rows = $db->loadObjectList();
		$db1->setQuery($query);
		
		$rows1 = $db1->loadObjectList();
		$totalrow=count($rows1);
		if($totalrow>0)
			$paging=CareersViewSeniorJob::pagingSubmit($totalrow,20,10,$page,"submitSearch");
		else
			$paging="";
		$i=0;
		$listsVacancy	= array();
		foreach( $rows as $row )
		{
			if($row->salary_min==$row->salary_max && $row->salary_max>0)
				$salary="Around $".$row->salary_max;
			else
			if($row->salary_min==$row->salary_max && $row->salary_max==0)
				$salary="Negotiable";
			else
			if($row->salary_min>0 && $row->salary_max==0)
				$salary="Above $".$row->salary_min;
			else			
			if($row->salary_min==0 && $row->salary_max>0)
				$salary="Up to $".$row->salary_max;
			else
				$salary="$".$row->salary_min. " - $".$row->salary_max;
				
			$location_id = CareersViewSeniorJob::getListName("#__vacancy_has_location", "vacancy_id='$row->vacancy_id'", "city_id");
			if($location_id=="")
				$location_id="''";
			else
				$location_id= str_replace("|",",",$location_id);
			$location = CareersViewSeniorJob::getListName("#__city_lookup", "city_id in($location_id)", "name");
			$listsVacancy[$i]->vacancy_id = $row->vacancy_id; 
			if($row->vacancy_code!="")
				$listsVacancy[$i]->code = $row->vacancy_code;
			else
				$listsVacancy[$i]->code = "&nbsp;";
			$listsVacancy[$i]->title = $row->title;
			$listsVacancy[$i]->salary = $salary;
			$listsVacancy[$i]->posted_date = date("M d, Y",strtotime($row->posted_date));
			$listsVacancy[$i]->location = $location;
			if($i%2)
				$listsVacancy[$i]->class = "row1";
			else
				$listsVacancy[$i]->class = "row0";
			$i++;
		}
		
		// Get the page/component configuration
		$params = &$mainframe->getParams();
		
		$this->assignRef('params',		$params);
		$this->assignRef('listLocationId',$listLocationId);
		$this->assignRef('listFunctionId',$listFunctionID);
		$this->assignRef('Itemid',$Itemid);
		$this->assignRef('listsVacancy',$listsVacancy);
		$this->assignRef('salary_range_id',$salary_range_id);
		$this->assignRef('industry_id',$industry_id);
		$this->assignRef('title',$title);
		$this->assignRef('paging',$paging);
		$this->assignRef('page',$page);
		
		//$this->assignRef('title',$title);
		
		parent::display($tpl);
	}
	
	function getListName($table,$condition,$field)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT distinct($field) as $field FROM $table WHERE $condition ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		$num = 0;
		$str = "";
		foreach( $rows as $row )
		{
			if ( $num==0 )
				$str = $row->$field;
			else
				$str.= " | ".$row->$field;
			$num++;
		}
		return $str;
	}
	
	
public function pagingSubmit($TotalRows,$RowsInPage,$maxpage,$page,$jsname){
		if ($maxpage) $numfrom = 1;
		else $numfrom = 0;

		$numto = $RowsInPage;
		if ($TotalRows < $numto) $numto = $TotalRows;

		if($page >1){
			$numfrom = ($RowsInPage)*($page-1)+1;
			$numto = ($RowsInPage)*$page;

			if ($TotalRows < $numto) $numto = $TotalRows;
		}

		$arrnumpage=explode('.',$TotalRows/$RowsInPage);
		if ($TotalRows%$RowsInPage!=0)
		$numpage=$arrnumpage[0]+1;
		else
		$numpage=$arrnumpage[0];

		$vl=explode('.',$page/$maxpage);
		//if ($page%$maxpage==0)
		$step=$vl[0];

		if ($step==0)
		{
			$start=1;
			$step=1;
		}
		else
		if ($page%$maxpage==0)
		{
			$start=($step-1)*$maxpage+1;
		}
		else
		{
			$start=$step*$maxpage+1;
		}
		$end=$start+$maxpage-1;

		if ($page>1)
		$str="<a href='#' onClick=\"".$jsname."(".($page-1).");\">Back</a> &nbsp;";
		else
		$str="<font color='#999999'>Back &nbsp;</font>";
		//Middle
		if ($end<$numpage){
			$k=0;
			for($i=$start;$i<=$end;$i++){
				if ($k==0)
				{
					if ($i==$page)

					$str.="<b>".$i.'</b>';

					else
					$str.="<a href='#' onClick=\"".$jsname."(".$i.");\">".$i.'</a>';
				}
				else{
					if ($i==$page)

					$str.=" | <b>".$i.'</b>';

					else
					$str.=" | <a href=\"#\" onClick=\"".$jsname."(".$i.");\">".$i.'</a>';
				}
				$k++;
			}

		}
		else{
			if ($start==1)
			{
				$end=$numpage;
			}
			else
			if ($end-$numpage>0)
			{
				$start=$start-($end-$numpage);
				$end=$numpage;
			}
			else
			if ($end-$start<$maxpage)
			$start=$start-($end-$start);
			$k=0;
			for($i=$start;$i<=$end;$i++){
				if ($k==0)
				{
					if ($i==$page)

					$str.="<b>".$i.'</b>';
					else
					$str.="<a href='#' onClick=\"".$jsname."(".$i.");\">".$i.'</a>';
				}
				else{
					if ($i==$page)

					$str.=" | <b>".$i.'</b>';

					else
					$str.=" | <a href=\"#\" onClick=\"".$jsname."(".$i.");\">".$i.'</a>';
				}
					
				$k++;
			}
		}
			
		//Next

		if ($page<$numpage)
		{
			$str.=" &nbsp;<a href='#' onClick=\"".$jsname."(".($page+1).");\">Next</a>";
		}
		else
		$str.=' <font color="#999999">&nbsp;Next</font>';
		return $str.'<br />( '.$numfrom.'-'.$numto.' of '.$TotalRows.' records - Page '.$page.' of '.$numpage.' pages)';
	}
}
?>
