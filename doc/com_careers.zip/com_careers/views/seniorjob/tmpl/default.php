<?php defined('_JEXEC') or die('Restricted access');?>

<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>
	<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" style="padding-top:10px ">
		<?php echo $this->escape($this->params->get('page_title')); ?>
	</div>
<?php endif; ?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
  	<td>&nbsp;</td>
  </tr>
  <tr>
    <td >
	<form name="frmsearch" method="get" action="index.php?option=com_careers&view=seniorjob&Itemid=<?php echo $this->Itemid;?>">
	  <input type="hidden" name="option" value="com_careers" />
	  <input type="hidden" name="vacancy_id" value="<?php JRequest::getVar('vacancy_id');?>" />
	  <input type="hidden" name="view" value="seniorjob"/>
	  <input type="hidden" name="Itemid" value="<?php echo $this->Itemid;?>"/>
	  <input type="hidden" name="page" value="<?php echo $this->page;?>"/>
	  <input type="hidden" name="industry_id" value="<?php echo $this->industry_id;?>"/>
	  <input type="hidden" name="listFunctionId" value="<?php echo $this->listFunctionId;?>"/>
	  <input type="hidden" name="salary_range_id" value="<?php echo $this->salary_range_id;?>"/>
	  <input type="hidden" name="listLocationId" value="<?php echo $this->listLocationId;?>"/>
	  <input type="hidden" name="title" value="<?php echo $this->title;?>"/>
	 </form>
	</td>
  </tr>
  
  <tr>
    <td>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="adminlist">
		<thead>
		  <tr>
			<th width="60" align="center" nowrap="nowrap">Code</th>
			<th width="329" align="left" nowrap="nowrap"> Job Title</th>
			<th width="105" align="left" nowrap="nowrap"> <strong>Salary</strong></th>
			<th width="131" align="left" nowrap="nowrap"> Location</th>
			<th width="100" align="left" nowrap="nowrap">Posted Date</th>
		  </tr>
		</thead>
		<tfoot>
		</tfoot>
		<tbody>
		<?php if(count($this->listsVacancy)>0)
		{
		foreach ($this->listsVacancy as $item) :
			$link = JRoute::_("index.php?option=com_careers&view=jobdetail&vacancy_id=".$item->vacancy_id."&Itemid=132&industry_id=".$this->industry_id."&listFunctionId=".$this->listFunctionId."&listLocationId=".$this->listLocationId."&salary_range_id=".$this->salary_range_id."&title=".$this->title);
		?>
		  <tr class="<?php echo $item->class;?>">
			<td align="center" valign="top"><?php echo $item->code;?></td>
			<td align="left" valign="top"><a href="<?php echo $link ?>"><?php echo $item->title;?></a></td>
			<td align="left" valign="top"><?php echo $item->salary;?></td>
			<td align="left" valign="top"><?php echo $item->location;?></td>
			<td align="left" valign="top"><?php echo $item->posted_date;?></td>
		  </tr>
		 <?php endforeach;
		 }
		 else
		 {
		  ?>
		  <tr>
		  <td height="20" class="note_start" colspan="5" align="center"> No matching jobs found.</td>
		  </tr>
		 <?php }?>
		</tbody>
	  </table>	
	</td>
  </tr>
  <tr><td height="15"></td></tr>
  <tr><td align="center"><?php echo $this->paging;?></td></tr>
</table>
<script language="javascript">
function submitSearch(page)
{
	document.frmsearch.method="get";
	document.frmsearch.page.value=page;
	document.frmsearch.submit();
}
</script>