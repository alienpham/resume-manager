<?php defined('_JEXEC') or die('Restricted access');?>
<?php if($this->row->vacancy_status=="Active Public") {?>
<?php //$params = $this->get('params'); $params->get('show_print_icon');?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right"><a onclick="window.print();return false;" href="#">
		<img alt="Print" src="images/printButton.png" border="0" /> </a></td>
	</tr>
	<tr>
		<td height="10"></td>
	</tr>
	<tr>
		<td align="justify">
		<p class="title_info"><strong><?php echo $this->row->title;?></strong></p>
		<div align="justify">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td height="8" colspan="4"></td>
			</tr>
			<tr>
				<td width="20%" colspan="2"><strong>Job Code:</strong> <br>
				<strong>Salary:</strong> <br>
				<strong>Location: </strong><br>
				<strong>Function: </strong></td>
				<td width="80%" colspan="2"><?=$this->row->vacancy_code;?><br>
				<?=$this->salary;?><br>
				<?=$this->listsLocation;?><br>
				<?=$this->listsFunction;?><br>
				</td>
			</tr>
		</table>
		</div>
		<p align="justify"><strong>COMPANY INFORMATION</strong></p>
		
		 <img style="float: left; margin-right: 8px; margin-top: 2px;"
			src="<? echo JURI::base().'/components/com_careers/image.php?vacancy_id='.$this->row->vacancy_id ?>">

			<?php echo nl2br($this->company_profile);?>
		<p align="justify"><strong>RESPONSIBILITIES</strong></p>
		<?php echo nl2br($this->row->description);?>
		<p align="justify"><strong>REQUIREMENTS</strong></p>
		<p><?php echo nl2br($this->row->requirement);?></p>

		<p align="justify"><strong>APPLICATION</strong></p>
		<p>Alternatively, you can send your application to <a href="#">resume@vipsearch.com</a></p>
		</td>
	</tr>
</table>
		<?php } else {?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td height="10"></td>
	</tr>
	<tr>
		<td><strong><font size="+1">Job Not Found</font></strong></td>
	</tr>
	<tr>
		<td height="10"></td>
	</tr>
	<tr>
		<td align="justify">Sorry. It seems that this position is already
		closed. Please try &quot;Search&quot; feature to search for similar
		jobs. (Click &quot;Senior & Executive Jobs&quot; on the Left Menu).</td>
	</tr>
</table>

		<?php }?>