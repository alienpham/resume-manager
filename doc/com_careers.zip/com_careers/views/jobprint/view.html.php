<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');
require_once(JPATH_COMPONENT.DS.'views\jobdetail\view.html.php');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Weblinks
 * @since 1.0
 */
class CareersViewJobPrint extends CareersViewJobDetail
{
	var $images = array('logo_content'=>'',
						'logo_name'=>'',
						'logo_width'=>'',
						'logo_height'=>'',
						'logo_file_type'=>''							
						);
	function _display($tpl=null){
		$this->assignRef('params', $params);
	}
	
	function getImages(){
		$images2 = array('logo_content'=>'',
						'logo_name'=>'yyy',
						'logo_width'=>'',
						'logo_height'=>'',
						'logo_file_type'=>''							
						);
		$vacancy_id=JRequest::getVar("vacancy_id");
		$db =& JFactory::getDBO();
		$query="SELECT c.* FROM vip_company_profile c, vip_vacancy v
				WHERE c.company_profile_id=v.company_profile_id AND v.vacancy_id='".$vacancy_id."'";
		
 		$db->setQuery($query);
 		$rows = $db->loadObject();
 		$this->images2['logo_content'] = $rows->logo_content;
 		$this->images2['logo_name'] = $rows->logo_name;
 		$this->images2['logo_width'] = $rows->logo_width;
 		$this->images2['logo_height'] = $rows->logo_height;
 		$this->images2['logo_file_type'] = $rows->logo_file_type;
 		$this->images = $images2;
	}

}
?>
