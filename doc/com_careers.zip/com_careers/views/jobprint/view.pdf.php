<?php
/**
 * @version		$Id: view.pdf.php 11371 2008-12-30 01:31:50Z ian $
 * @package		Joomla
 * @subpackage	Content
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');
require_once(JPATH_COMPONENT.DS.'views\jobdetail\view.html.php');

/**
 * HTML Article View class for the Content component
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 1.5
 */
class CareersViewJobPrint extends CareersViewJobDetail
{

	function _display($tpl=null){
		$document = &JFactory::getDocument();
		$document->setTitle($rows->title);
		$document->setHeader($this->_getHeaderText($rows, $params));
		echo '<h1>' . JText::_('JOB DESCRIPTION') . '</h1><br>';

		$this->assignRef('params',	$params);
	}

	function _getHeaderText(& $article, & $params)
	{
		// Initialize some variables
		$text = 'set header here';
		return $text;
	}
/*
	function display($tpl = null){
		global $mainframe;
		$Itemid=JRequest::getVar("Itemid");
		$vacancy_id=JRequest::getVar("vacancy_id");
		$option=JRequest::getVar("option");
		$view=JRequest::getVar("view");

		$db =& JFactory::getDBO();
		$query="SELECT * FROM #__vacancy WHERE vacancy_id='".$vacancy_id."'";

		$db->setQuery($query);
		$rows = $db->loadObject();
		//print_r( $rows );
		$listsLocation_id= CareersViewJobDetail::getListName("#__vacancy_has_location", "vacancy_id='".$vacancy_id."'","city_id");
		if($listsLocation_id=="")
		$listsLocation_id="''";
		$listsLocation= CareersViewJobDetail::getListName("#__city_lookup", "city_id in(".$listsLocation_id.")","name");
			
		$listsFunction_id= CareersViewJobDetail::getListName("#__vacancy_has_function", "vacancy_id='".$vacancy_id."'","function_id");
		if($listsFunction_id=="")
		$listsFunction_id="''";
		$listsFuntion= CareersViewJobDetail::getListName("#__function_lookup", "function_id in(".$listsFunction_id.")","name");
			
			
		// Get the page/component configuration
		$params = &$mainframe->getParams();
		$company_profile= CareersViewJobDetail::getListName("#__company_profile", "company_profile_id ='".$rows->company_profile_id."'","introduction");
		if($rows->salary_min==$rows->salary_max && $rows->salary_max>0)
		$salary="Around $".$rows->salary_max;
		else
		if($rows->salary_min==$rows->salary_max && $rows->salary_max==0)
		$salary="Negotiable";
		else
		if($rows->salary_min>0 && $rows->salary_max==0)
		$salary="Above $".$rows->salary_min;
		else
		if($rows->salary_min==0 && $rows->salary_max>0)
		$salary="Up to $".$rows->salary_max;
		else
		$salary="$".$rows->salary_min. " - $".$rows->salary_max;

		$this->assignRef('params',$params);
		$this->assignRef('salary',$salary);
		$this->assignRef('company_profile',$company_profile);
		$this->assignRef('listsLocation',$listsLocation);
		$this->assignRef('listsFunction',$listsFuntion);
		$this->assignRef('row',$rows);

		if($rows->vacancy_status=="Closed" || $rows->vacancy_status=="")
		 $this->assignRef('show',"0");
		 else
		 $this->assignRef('show',"1");


		$document = &JFactory::getDocument();
		$document->setTitle($rows->vacancy_id);
		$document->setHeader($this->_getHeaderText($rows, $params));
		echo '<h1>' . JText::_('JOB DESCRIPTION') . '</h1><br>';
		//echo 'Position: <b>'.JText::_(strtoupper($rows->title)).'</b><br>';

		//echo '<br> '. JText::_($rows->vacancy_code).'<br>';
		//echo '<br>Salary: '. JText::_($salary).'<br>';
		//echo '<br>Location: '. JText::_($listsLocation).'<br>';
		//echo '<br>Function: '. JText::_($salary).'<br>';
		//echo '<br>Posted: '. JText::_(date("M d, Y",strtotime($rows->posted_date)) ).'<br>';


		echo '<table width="100%"  border="0" align="left">
		 <tr>
		 <td>Position:</td>
		 <td><b>'. JText::_(strtoupper($rows->title)).'</b></td>
		 </tr>
		 <tr>
		 <td>Job Code:</td>
		 <td>'. JText::_($rows->vacancy_code).'</td>
		 </tr>
		 <tr>
		 <td>Location:</td>
		 <td> '. JText::_($listsLocation).'</td>
		 </tr>
		 <tr>
		 <td>Function:</td>
		 <td>'. JText::_($salary).'</td>
		 </tr>
		 <tr>
		 <td>Posted:</td>
		 <td>'. JText::_(date("M d, Y",strtotime($rows->posted_date))).'</td>
		 </tr>
			</table>';
			
		//return;
		//parent::display($tpl);
	}
	
	function getListName($table,$condition,$field)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT distinct($field) as $field FROM $table WHERE $condition ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		$num = 0;
		$str = "";
		foreach( $rows as $row )
		{
			if ( $num==0 )
			$str = $row->$field;
			else
			$str.= " | ".$row->$field;
			$num++;
		}
		return $str;
	}

	function display1($tpl = null)
	{
		//global $mainframe;
		//$user		=& JFactory::getUser();
		//$dispatcher	=& JDispatcher::getInstance();

		// Initialize some variables
		$jobdetail	= & $this->get( 'Jobdetail' );
		$params 	= & $jobdetail->parameters;

		// Create a user access object for the current user
			$access = new stdClass();
		$access->canEdit	= $user->authorize('com_content', 'edit', 'content', 'all');
		$access->canEditOwn	= $user->authorize('com_content', 'edit', 'content', 'own');
		$access->canPublish	= $user->authorize('com_content', 'publish', 'content', 'all');

		// Check to see if the user has access to view the full article
		//$aid	= $user->get('aid');

				if (($article->access > $aid) && ( ! $aid )) {
			// Redirect to login
			$uri		= JFactory::getURI();
			$return		= $uri->toString();

			$url  = 'index.php?option=com_user&view=login';
			$url .= '&return='.base64_encode($return);;

			//$url	= JRoute::_($url, false);
			$mainframe->redirect($url, JText::_('You must login first') );
			}
			else
		if (1) {
			$document = &JFactory::getDocument();
			$document->setTitle('Title');
			$document->setHeader($this->_getHeaderText($jobdetail, $params));
			echo '<h1>' . JText::_('test') . '</h1>';
			return;
		}

		// process the new plugins
		JPluginHelper::importPlugin('content', 'image');
		$dispatcher->trigger('onPrepareContent', array (& $jobdetail, & $params, 0));

		$document = &JFactory::getDocument();

		// set document information
		$document->setTitle('title here');
		$document->setName('alias name');
		$document->setDescription('setDescription');
		$document->setMetaData('keywords', 'tessss');
		$document->

		// prepare header lines
		$document->setHeader($this->_getHeaderText($jobdetail, $params));

		//echo $jobdetail->text;
		echo JText::_('testing');
		//parent::display($tpl);
	}
*/
}
?>
