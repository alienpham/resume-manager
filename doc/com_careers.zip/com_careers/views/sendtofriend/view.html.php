<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the SendtoFriend component
 *
 * @static
 * @package		Joomla
 * @subpackage	SendtoFriend
 * @since 1.0
 */
class CareersViewSendtofriend extends JView
{
	function display($tpl = null)
	{
		global $mainframe;
		
		$db =& Jfactory::getDBO();
		$vacancy_id		= $_GET['vacancy_id'];

		$validemail = JRequest::getVar('validemail', '');
		
		$query	= 'SELECT * FROM #__vacancy WHERE vacancy_id = '.$vacancy_id;
		$db->setQuery($query);
		$vacancy = $db->loadObject();
		
		if($validemail)
		{
			$name 			= JRequest::getVar('name', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$email 			= JRequest::getVar('email', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$friend_name 	= JRequest::getVar('friend_name', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$friend_email 	= JRequest::getVar('friend_email', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$message 		= JRequest::getVar('message', '', 'post', 'string', JREQUEST_ALLOWRAW);
		
			$this->assignRef('name',  $name);
			$this->assignRef('email',  $email);
			$this->assignRef('friend_name',  $friend_name);
			$this->assignRef('friend_email',  $friend_email);
			$this->assignRef('message',  stripslashes($message));
			$this->assignRef('validemail',  $validemail);
		}
		
		$this->assignRef('vacancy',  $vacancy);
		$this->assignRef('vacancy_id',  $vacancy_id);
		
		parent::display($tpl);
	}
}
?>
