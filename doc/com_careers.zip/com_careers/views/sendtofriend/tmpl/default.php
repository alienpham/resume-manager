<p class="contentheading"><?php echo JText::_('SEND TO FRIEND');?></p>
<p>Fields marked with (<span class="note_start">*</span>) are required:</p>
<p class="note_start">
<?php echo @$this->validemail; ?>
</p>
<form name="sendtofriend" method="post" action="<?php echo JRoute::_('index.php?option=com_careers&task=sendmail&vacancy_id='.$this->vacancy_id.'&Itemid=136'); ?>" >
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="29%" height="30"><strong>Job Details:</strong></td>
		<td width="71%"><strong><?php echo @$this->vacancy->title ?> (Code: <?php echo @$this->vacancy->vacancy_code; ?>)</strong></td>
	</tr>
	<tr>
		<td height="30"><strong>Your Name:</strong><span class="note_start">*</span></td>
		<td><input type="text" name="name" value="<?php echo @$this->name ?>" style="width: 280px" /></td>
	</tr>
	<tr>
		<td height="30"><strong>Your Email:</strong><span class="note_start">*</span></td>
		<td><input type="text" name="email" value="<?php echo @$this->email ?>" style="width: 280px" /></td>
	</tr>
	<tr>
		<td height="30"><strong>Your Friend's Name:</strong><span
			class="note_start">*</span></td>
		<td><input type="text" name="friend_name" value="<?php echo @$this->friend_name ?>" style="width: 280px" /></td>
	</tr>
	<tr>
		<td height="30"><strong>Your Friend's Email:</strong><span
			class="note_start">*</span></td>
		<td><input type="text" name="friend_email" value="<?php echo @$this->friend_email ?>" style="width: 280px" /></td>
	</tr>
	<tr>
		<td height="5" colspan="2"></td>
	</tr>
	<tr>
		<td height="30" valign="top"><strong>Your Message:</strong><span
			class="note_start">*</span></td>
		<td><textarea name="message" rows="6" style="width: 280px"><?php echo @$this->message ?></textarea></td>
	</tr>
	<tr>
		<td height="10" colspan="2"></td>
	</tr>
	<tr>
		<td height="30" valign="top">&nbsp;</td>
		<td>
			<input type="submit" name="send" value=" Send " />
			&nbsp;&nbsp; 
			<input type="reset" name="cancel" value="Cancel" /></td>
	</tr>
</table>
<input type="hidden" name="option" value="com_careers" />
<input type="hidden" name="view" value="sendtofriend" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>