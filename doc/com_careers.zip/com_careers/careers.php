<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Initialize some variables
$document	= &JFactory::getDocument();

//setMetaData description and keywords
$document->setMetaData('description', 'VIPsearch provides thousands of senior and top management positions across 5 industries: Consuming, Finance & Banking, ICT, Industrial and Services.', 'http-equiv');
$document->setMetaData('keywords', 'Vipsearch, VIPsearch, vipsearch, vip seach, executive search, executive search firms, international executive search, retained executive search firm, retained executive search firms, top executive search firm, executive search consultants, executive search recruitment, retained executive search, top executive search firms, executive jobs, search executive jobs, executive job search, executive positions, executive head hunter, executive job, executive headhunters, executive placement, executive recruiters, executive recruitment, executive head hunters, executive headhunter, executive recruiter, executive recruiting, executive research, executive, executive employment, executive careers, job search, job vacancies, recruitment agencies, recruitment, recruitment agency, recruiters, employment, employment agencies, employment agency, head hunter, head hunters, headhunter, headhunters, recruiting agency, recruiter, recruiter, recruitment, employment agencies, headhunter, headhunter Vietnam, career opportunities, executive jobs, senior executive , CEO, CIO, CFO, HR, Sales, Marketing, QA/QC, Engineering, Plant Manager, Legal Risk & Compliances, consuming, finance & banking, ict, information & communication technology, industrial, service
', 'http-equiv');
$document->setTitle( "VIPsearch - Career Opportunities | Find Talents. Add Values." );
// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once(JPATH_COMPONENT.DS.'careers_library.php');

// Create the controller
$controller = new CareersController();

// Perform the Request task
$controller->execute( JRequest::getCmd('task'));

// Redirect if set by the controller
$controller->redirect();
