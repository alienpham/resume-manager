<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.controller');
require_once(JPATH_COMPONENT.DS.'views\jobdetail\view.html.php');

/**
 * User Component Controller
 *
 * @package		Joomla
 * @subpackage	Carrers
 * @since 1.5
 */
class CareersController extends JController
{
	/**
	 * Method to display a view
	 *
	 * @access	public
	 * @since	1.5
	 */
	function display()
	{
		parent::display();
	}

	/**
	 * remove my application
	 */
	function removeMyapplication()
	{
		$id		= JRequest::getInt('id', 0);
		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');
		
		$link = JRoute::_('index.php?option=com_members&view=login&Itemid=133');
		if(!$member_id)	$this->setRedirect( $link );
		
		$model = $this->getModel('Myapplication');

		if(!$model->removeMyApplication($id, $member_id)) 
		{
			$msg = JText::_( 'Error: One or More my application Could not be Deleted' );
		
		} else {
			$msg = JText::_( 'The job from My Applications had been deleted.' );
		}
		
		$link = JRoute::_('index.php?option=com_careers&view=myapplication&Itemid=86');
		$this->setRedirect( $link, $msg );
	}

	function removeMySaveJob()
	{
		$id		= JRequest::getInt('id', 0);
		$model = $this->getModel('Mysavejob');

		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');

		if(!$model->removeMySaveJob($id, $member_id)) {
			$msg = JText::_( 'Error: One or More my save job Could not be Deleted' );
		} else {
			$msg = JText::_( 'The job from My Save Jobs had been deleted.' );
		}
		
		$link = JRoute::_('index.php?option=com_careers&view=mysavejob&Itemid=87');
		$this->setRedirect( $link, $msg );
	}

	function saveJob()
	{
		$vacancy_id	= JRequest::getVar('vacancy_id', 0, '', 'int');
		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');
		$model = $this->getModel('Mysavejob' );

		$msg1 = 'You are not login, please login for save job.';
		$msg2 = 'Save job had been successfull.';

		if(!$member_id) 
		{
			$link = JRoute::_('index.php?option=com_members&view=login&Itemid=133');	
			$this->setRedirect( $link, $msg1 );
			
		}else{
			if(!$model->checkMySaveJob($member_id, $vacancy_id)){
				if(!$model->saveJob($member_id, $vacancy_id)) {
					$msg = JText::_( 'Error: One or more job Could not be saved' );
				} else {
					$msg = JText::_( 'My save job had been done.' );
				}
			}
			
			$link = JRoute::_('index.php?option=com_careers&view=mysavejob&Itemid=87');
			$this->setRedirect( $link, $msg2 );
		}
	}

	function getListName($table,$condition,$field)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT distinct($field) as $field FROM $table WHERE $condition ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		$num = 0;
		$str = "";
		foreach( $rows as $row )
		{
			if ( $num==0 )
			$str = $row->$field;
			else
			$str.= " | ".$row->$field;
			$num++;
		}
		return $str;
	}

	function sendMail()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );
		jimport('joomla.mail.helper');

		$vacancy_id = JRequest::setVar('vacancy_id', '0');

		$db =& Jfactory::getDBO();
		$query	= 'SELECT * FROM #__vacancy WHERE vacancy_id = '.$vacancy_id;
		$db->setQuery($query);
		$vacancy = $db->loadObject();
		
		$query	= 'SELECT name FROM #__city_lookup WHERE city_id in (SELECT city_id FROM #__vacancy_has_location WHERE vacancy_id = '.$vacancy_id.')';
		$db->setQuery($query);
		$city = $db->loadResultArray();
		$city = implode(',', $city);		
		
		$name 			= JRequest::getVar('name', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$email 			= JRequest::getVar('email', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$friend_name 	= JRequest::getVar('friend_name', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$friend_email 	= JRequest::getVar('friend_email', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$body 			= JRequest::getVar('message', '', 'post', 'string', JREQUEST_ALLOWRAW);

		if( !$name || !$email || !$friend_name || !$friend_email || !$body)
		{
			JRequest::setVar('validemail', 'Please enter this information.');
			$this->display();
			return false;

		}else if(JMailHelper::isEmailAddress($email) == false)
		{
			JRequest::setVar('validemail', 'Invalid email. Please check.');
			$this->display();
			return false;
		}

		$link 		 =  JURI::base().'index.php?option=com_careers&view=jobdetail&vacancy_id='.$vacancy_id.'&Itemid=132';

		$message 	 = "Hi $friend_name, \r\n";
		$message 	.= "\r\nYour friend, $name ($email), send you this job from VIPsearch.com:\n\r";
		$message 	.= "Job Title:".$vacancy->title."\r\n";
		$message 	.= "Job Code:".$vacancy->vacancy_code."\r\n";
		$message 	.= "Location: $city\r\n";
		$message 	.= "Salary:".$vacancy->salary_min." - ".$vacancy->salary_max."\r\n";
		$message 	.= "Posted Date:".$vacancy->posted_date."\r\n";
		$message 	.= "Job Description (click to the link): ". $link."\r\n";
		$message 	.= "Please see his/ her message below:\r\n\r\n";
		$message 	.= "$body";

		$subject 	= $vacancy->title.' (Job Code: '.$vacancy->vacancy_code.')';
		$mailfrom	= $email;
		$fromname 	= $name;

		JUtility::sendMail($mailfrom, $fromname, $friend_email, $subject, $message, 0, "resume@vipsearch.com", null, null, $email, $name );
		
		$_SESSION['link'] = JRoute::_('index.php?option=com_careers&view=jobdetail&vacancy_id='.$vacancy_id.'&Itemid=132');
		$link = 'index.php?option=com_careers&view=comfirmation&Itemid=136';
		$this->setRedirect($link, 'Job was sent successfully. Thank you.');
		
		//JRequest::setVar('validemail', 'You have sent a mail successfully.');
		//$this->display();
	}
	
	function login()
	{
		global $mainframe;
		ini_set("magic_quotes_sybase",0);
		jimport('joomla.mail.helper');
		$app			=& JFactory::getApplication();
		$email		= JRequest::getVar('email', null, 'post', 'string');
		$password 	= JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		$vacancy_id = JRequest::getInt('vacancy_id', 0);
		$chkresume 	= JRequest::getVar('chkresume', '0');
		$youremail 	= JRequest::getVar('youremail', null, 'post', 'string');
		$name 		= JRequest::getVar('name', null, 'post', 'string');
		$apply 		= $_POST['apply'];
		$filename 	= JRequest::getVar('filename');

		$db =& Jfactory::getDBO();
		$query	= 'SELECT v.*, c.full_name, c.email FROM #__vacancy as v INNER JOIN #__consultants as c '; 
		$query	.= 'ON v.consultant_id = c.consultant_id WHERE vacancy_id = '.$vacancy_id;
		$db->setQuery($query);
		$vacancy = $db->loadObject();
		
		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');
		//echo $session->get('email');
		$link = 'index.php?option=com_careers&view=jobdetail&vacancy_id='.$vacancy_id.'&Itemid=132';

		if ($apply == 'Login')
		{
			$this->checkLogin($password, $email, $vacancy_id);
			
		}else{
			$mailfrom 	= $mainframe->getCfg('mailfrom');
			$fromname 	= $mainframe->getCfg('fromname');
		
			if($chkresume == 'haslogin'){
					
				if($member_id)
				{
					echo $sql = "SELECT * FROM #__members_has_application WHERE vacancy_id='$vacancy_id' AND member_id='$member_id'";
					$db->setQuery($sql);
					$row=$db->loadObject();
					$sql = "SELECT * FROM #__resume WHERE member_id='$member_id'";
					$db->setQuery($sql);
					$rs_file=$db->loadObject();
					
					if ($rs_file->file_content!="")
					{
						if($row->vacancy_id=="")
						{
								$message 	= "\r\nThis application was sent to you via VIPsearch.com, on behalf of ".$session->get('name').'('.$session->get('email').")\n\r";
						
								$subject 	= 'Apply for '.$vacancy->title.' ('.$vacancy->vacancy_code.')';
		
								$f=fopen($_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".$rs_file->name, "w");
								fwrite($f,$rs_file->file_content);
								$file_name=$_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".$rs_file->name;
														
								JUtility::sendMail($mailfrom, $fromname, $vacancy->email, $subject, $message, 0, "resume@vipsearch.com", null, $file_name, $session->get('email'),$name);
								unlink($file_name);
								$query	= 'INSERT INTO #__members_has_application(member_id, vacancy_id, applied_date) VALUES';
								$query	.= '("'.$member_id.'","'.$vacancy_id.'","'.date('Y-m-d H:i:s').'");';
							
								$db->setQuery($query);
								if(!$db->query()) {
									return JError::raiseWarning( 500, $db->getError() );
								}
								
								$query="UPDATE #__vacancy SET applied_count=applied_count+1 WHERE vacancy_id=".$vacancy_id."";
								$db->setQuery($query);
								if (!$db->query()) {
									JError::raiseError( 500, $db->getErrorMsg() );
									return false;
								}
								$_SESSION['link'] ='index.php?option=com_careers&view=myapplication&Itemid=86';
								$link = 'index.php?option=com_careers&view=comfirmation&Itemid=136';
								
								$this->setRedirect($link, 'Your application has been sent.');
						}
						else
						{
							$_SESSION["message_mail"] 	= "\r\nThis application was sent to you via VIPsearch.com, on behalf of ".$session->get('name').'('.$session->get('email').")\n\r";
							$_SESSION["subject_mail"] 	= 'Apply for '.$vacancy->title.' ('.$vacancy->vacancy_code.')';
							
							$_SESSION['link_viewjob'] = "index.php?option=com_careers&view=jobdetail&vacancy_id=$vacancy_id&Itemid=132";
							$_SESSION['link'] = 'index.php?option=com_careers&view=myapplication&Itemid=86';
							$link = "index.php?option=com_careers&view=comfirmation&case=1&vacancy_id=$vacancy_id&Itemid=136";
							$this->setRedirect($link, 'You have already applied for this position. It is unneccessary to apply again, unless you have a reason to do so. Do you want to proceed?');
						}
					}
					else
					{
						$link="index.php?option=com_members&view=update&Itemid=85";
						$mainframe->redirect($link);
					}
				}else
				{
					$this->checkLogin($password, $email, $vacancy_id);	
				}
			}
			else
			{
			
				$tmp_name = $_FILES['file']['tmp_name'];
				$err=true;
				if ( !trim($name) || !trim($youremail) || trim($name)=="Your fullname")
				{
						
					$err=false;
					$_SESSION['cache_email2'] = $youremail;
					$_SESSION['cache_name'] = $name;
					$this->setRedirect($link, '2 Please enter this information.');
					
				}
				else 
				if( JMailHelper::isEmailAddress($youremail) == false )
				{
					
					$err=false;		
					$_SESSION['cache_email2'] = $youremail;
					$_SESSION['cache_name'] = $name;		
					$this->setRedirect($link, '2 Invalid email. Please check.');
					
				}
				if($tmp_name=="")
				{
		
					$err=false;
					$this->setRedirect($link, '2 Please select file attachment.');
					
				}
				else
				if(!empty($tmp_name)){
				
					$extent_file="doc|docx|pdf";
					
					if ($_FILES["file"]["error"] > 0) 
					{
		
						$err=false;
						$this->setRedirect($link, '2 Invalid file format. Please convert your resume into Word or Pdf format.');
						
					
					}else if(!preg_match("/\\.(" . $extent_file . ")$/", strtolower($_FILES["file"]["name"])) || $_FILES["file"]["size"] > 2097152)
					{
			
						$err=false;
						$this->setRedirect($link, '2 Invalid file format. Please convert your resume into word or pdf format.');
						
					}
					$message 	= "\r\nThis application was sent to you via VIPsearch.com, on behalf of $name ($youremail).\n\r";
			
					$subject 	= 'Apply for '.$vacancy->title.' ('.$vacancy->vacancy_code.')';
					if($err)
					{
						$f = fopen($tmp_name, "rb");
						$contents = fread($f, filesize($tmp_name));
						fclose($f);
						$contents = addslashes($contents);
						$sql="SELECT * FROM #__non_members WHERE vacancy_code='$vacancy->vacancy_code' AND email='$youremail'";
						$db->setQuery($sql);
						$row=$db->loadObject();
						//echo $row->non_member_id;
						if($row->non_member_id!="")
						{
							$_SESSION["message_mail"] 	= "\r\nThis application was sent to you via VIPsearch.com, on behalf of $name ($youremail).\n\r";
							$_SESSION["subject_mail"] 	= 'Apply for '.$vacancy->title.' ('.$vacancy->vacancy_code.')';
							$_SESSION['full_name']=$name;
							$_SESSION['youremail']=$youremail;
							if($member_id)
								$_SESSION['link'] = 'index.php?option=com_careers&view=myapplication&Itemid=86';
							else
								$_SESSION['link'] = "index.php?option=com_careers&view=jobdetail&vacancy_id=$vacancy_id&Itemid=132";
							$_SESSION['file_name']=$_FILES["file"]["name"];
							$_SESSION['file_type']=$_FILES["file"]["type"];
							$_SESSION['file_size']=$_FILES["file"]["size"];
							
							$_SESSION['link_viewjob'] = "index.php?option=com_careers&view=jobdetail&vacancy_id=$vacancy_id&Itemid=132";
							$link = "index.php?option=com_careers&view=comfirmation&case=2&vacancy_id=$vacancy_id&Itemid=136";
							//echo $_SERVER['DOCUMENT_ROOT'];
							copy( $tmp_name, $_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".str_replace(" ","_",$_FILES["file"]["name"]));							
							
							echo "
							<form name='login' method='post' enctype='multipart/form-data'>
							 <input type='hidden' name='file' value='' >
							 <input type='hidden' name='mess' value='You have already applied for this position. It is unneccessary to apply again, unless you have a reason to do so. Do you want to proceed?'>
								<script>
									function sbForm(){
									document.login.method='post';
									document.login.action='$link';
									document.login.submit();
									}
									sbForm();
								  </script>
								 
							</form>";
							exit;
							//$this->setRedirect($link, 'You have already applied for this position. It is unneccessary to apply again, unless you have a reason to do so. Do you want to proceed?');
						}
						else
						{
							$query	= 'INSERT INTO #__non_members(full_name, email, file_name, file_type, file_size, file_content, vacancy_code, applied_date) VALUES';
							$query	.= "('".$name."','".$youremail."','".$_FILES["file"]["name"]."','".$_FILES["file"]["type"]."',";
							$query	.= "'".$_FILES["file"]["size"]."','".$contents."',";
							$query	.= "'".$vacancy->vacancy_code."','".date('Y-m-d H:i:s')."'";
							$query	.= ')';
	
							$db->setQuery($query);
							if(!$db->query()) {
								return JError::raiseWarning( 500, $db->getError() );
							}
							
							if($member_id)
							{
								$sql_apply="SELECT * FROM #__members_has_application WHERE vacancy_id='$vacancy->vacancy_id' AND member_id='$member_id'";
								$db->setQuery($sql_apply);
								$row_apply=$db->loadObject();
								if($row_apply->id!="")
								{
									$sql="UPDATE #__members_has_application SET applied_date='".date('Y-m-d H:i:s')."' WHERE id='$row_apply->id'";
									$db->setQuery($sql);
									if(!$db->query()) {
										return JError::raiseWarning( 500, $db->getError() );
									}
								}
								else
								{
									$sql="INSERT INTO #__members_has_application(member_id,vacancy_id,applied_date) VALUES('$member_id','$vacancy->vacancy_id','".date('Y-m-d H:i:s')."')";
									$db->setQuery($sql);
									if(!$db->query()) {
										return JError::raiseWarning( 500, $db->getError() );
									}
								}
								$_SESSION['link'] = 'index.php?option=com_careers&view=myapplication&Itemid=86';
							}
							else
								$_SESSION['link'] = "index.php?option=com_careers&view=jobdetail&vacancy_id=$vacancy_id&Itemid=132";
							
							$file= $_SERVER['DOCUMENT_ROOT'].$app->getCfg('file_path')."/tmp/".str_replace(" ","_",$_FILES["file"]["name"]);
							copy( $tmp_name,$file);
							
							JUtility::sendMail($mailfrom, $fromname, $vacancy->email, $subject, $message, 0, "resume@vipsearch.com", null, $file, $youremail, $name);
							unlink($file);
							
							$query="UPDATE #__vacancy SET applied_count=applied_count+1 WHERE vacancy_id=".$vacancy_id."";
							$db->setQuery($query);
							if (!$db->query()) {
								JError::raiseError( 500, $db->getErrorMsg() );
								return false;
							}
						
							$link = 'index.php?option=com_careers&view=comfirmation&Itemid=136';
							$this->setRedirect($link, 'Your application has been sent.');
						}
					}
				}
			}
		}
		
	}
	
	function viewPdf(){

		$vacancy_id	= JRequest::getInt('vacancy_id', 0);

		$db =& JFactory::getDBO();
		$query = "SELECT * FROM #__vacancy WHERE vacancy_id = ".$vacancy_id;

		$db->setQuery($query);
		if(!$db->query()) {
			return JError::raiseWarning( 500, $db->getError() );
		}
		
		$row = $db->loadObject();
		
		$listsLocation_id = $this->getListName("#__vacancy_has_location", "vacancy_id='".$vacancy_id."'","city_id");
		if($listsLocation_id=="") $listsLocation_id="''";
		$listsLocation = $this->getListName("#__city_lookup", "city_id in(".$listsLocation_id.")","name");
			
		$listsFunction_id = $this->getListName("#__vacancy_has_function", "vacancy_id='".$vacancy_id."'","function_id");
		if($listsFunction_id=="") $listsFunction_id="''";
		$listsFuntion= $this->getListName("#__function_lookup", "function_id in(".$listsFunction_id.")","name");
			
		if($row->salary_min == $row->salary_max && $row->salary_max > 0)
			$salary = "Around $".$row->salary_max;
		
		else if($row->salary_min == $row->salary_max && $row->salary_max == 0)
			$salary = "Negotiable";
		
		else if($row->salary_min > 0 && $row->salary_max == 0)
			$salary = "Above $".$row->salary_min;
		
		else if($row->salary_min == 0 && $row->salary_max > 0)
			$salary = "Up to $".$row->salary_max;
		
		else $salary = "$".$row->salary_min. " - $".$row->salary_max;
		
		jimport('tcpdf.config.lang.eng');
		jimport('tcpdf.tcpdf');
		
		// create new PDF document
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false); 

		// set default header data
		$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH );
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		//$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		//set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		//set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		//set image scale factor
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO); 
		
		//set some language-dependent strings
		//$pdf->setLanguageArray($l); 
		//---------------------------------//
		
		
		// add a page
		$pdf->AddPage();
		
		// set JPEG quality
		$pdf->setJPEGQuality(75);

		//Image logo vipsearch
		//$pdf->Image('images/logo_vipsearch.jpg', 0, 0, 173, 48, '', 'http://www.vipsearch.com', 'L');

		$pdf->SetFillColor(150, 150, 150);
		//$pdf->SetTextColor(0,0,255);
		
		$pdf->SetFont('freeserif', '', 12);
		$pdf->Cell(0, 10, 'JOB DESCRIPTION', 0, 0, 'C');
		$pdf->ln(10);
		
		$pdf->SetFont('freeserif', '', 9);
		$html = '
			<table width="100%">
				<tr><td width="100">Position:</td><td>'.$row->title.'</td></tr>
				<tr><td width="100">Job Code:</td><td>'.$row->vacancy_code.'</td></tr>
				<tr><td width="100">Salary:</td><td>'.$salary.'</td></tr>
				<tr><td width="100">Location:</td><td>'.$listsLocation.'</td></tr>
				<tr><td width="100">Function:</td><td>'.$listsFuntion.'</td></tr>
				<tr><td width="100">Posted:</td><td>'.$row->posted_date.'</td></tr>
			</table>	
		';
		$pdf->writeHTML($html, true, 0, true, 0);
				
		$pdf->ln(5);	
		$pdf->Cell(0, 5, 'RESPONSIBILITIES', 0, 1, 'L', 1, 0);
		$pdf->ln(2);
		$pdf->writeHTML(nl2br($row->description), true, 0, true, 0);
		
		$pdf->ln(5);
		$pdf->Cell(0, 5, 'REQUIREMENTS', 0, 1, 'L', 1, 0);
		$pdf->ln(2);
		$pdf->writeHTML(nl2br($row->requirement), true, 0, true, 0);
		
		$text = 'To apply for this position, please send your resume to <a href="mailto:resume@vipsearch.com">resume@vipsearch.com</a>. Please include the job code in your application.';		
		$pdf->ln(5);
		$pdf->Cell(0, 5, 'APPLICATION', 0, 1, 'L', 1, 0);
		$pdf->ln(2);
		$pdf->writeHTML($text, true, 0, true, 0);
		
		$pdf->lastPage();
		
		//Close and output PDF document
		$pdf->Output($row->title.'.pdf', 'D');
		
		exit;

	}
	
	function checkLogin($password, $email, $vacancy_id){
		
		$link = JRoute::_('index.php?option=com_careers&view=jobdetail&vacancy_id='.$vacancy_id.'&Itemid=132');
		jimport('joomla.mail.helper');
		if ( !trim($password) || !trim($email))
		{
  			$this->setRedirect($link, '1 Please enter this information.');
		
		}else if( JMailHelper::isEmailAddress($email) == false ){
		 
			$_SESSION['cache_email1'] = $email;
  			$this->setRedirect($link, '1 Invalid email. Please check.');
		}
		
		$db =& Jfactory::getDBO();
		$query	= 'SELECT member_id, full_name, email FROM #__members WHERE email = "'.$email.'" AND password = "'.md5($password).'"';
		$db->setQuery($query);
		$row = $db->loadObject();

		if(!@$row->member_id){
					
			$_SESSION['cache_email1'] = $email;
  			$this->setRedirect($link, '1 Email or Password not correct');
		
		}else{
			
			$session =& JFactory::getSession();
  			$session->set('member_id', $row->member_id);
  			$session->set('email', $row->email);
  			$session->set('name', $row->full_name);
 			  			
  			$this->setRedirect($link); 
  		}
	}

}
?>
