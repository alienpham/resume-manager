<?php
class TOOLBAR_careers
{
	function _DEFAULT()
	{
		global $filter_state;

		JToolBarHelper::title( JText::_( 'Careers Manager' ), 'article.png' );
		JToolBarHelper::custom('exportNewletter','restore.png','restore_f2.png', 'Export Newletter', false);
		JToolBarHelper::custom('exportVacancy','restore.png','restore_f2.png', 'Export Vacancy', false);
	
	}
}

?>