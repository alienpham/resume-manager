<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.model');

class CareersModelMyapplication extends JModel
{
	var $_data = array();
	var $_total = null;
	var $_pagination = null;

	function __construct()
	{
		parent::__construct();

		$application = JFactory::getApplication() ;

		$config = JFactory::getConfig() ;

		$limitstart = JRequest::getInt( 'limitstart', 0 );
		$limit = $application->getUserStateFromRequest( 'global.list.limit', 'limit', $config->getValue('config.list_limit'), 'int' );
		//$limit =2;

		$this->setState('limitstart', $limitstart);
		$this->setState('limit', $limit);
	}

	function _loadData(){
		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');

		if (empty($this->_data) && empty($this->_total))
		{
			if($member_id)
			$query="select m.*,v.title, c.prefix_name, c.full_name, c.office_phone from #__members_has_application as m, #__vacancy as v, #__consultants as c
			where m.vacancy_id = v.vacancy_id and v.consultant_id=c.consultant_id and member_id=$member_id and DATEDIFF(curdate(), m.applied_date)<93;"; //< 3 months
			else
			$query = '';
			$this->_db->setQuery($query);

			$this->_data = $this->_db->loadObjectList();
			$this->_total = count( $this->_data ) ;
		}
		return $this->_data ;
	}

	function getData()
	{
		$this->_loadData() ;

		$limitstart = $this->getState('limitstart');
		$limit = $this->getState('limit');

		return array_slice( $this->_data, $limitstart, $limit );
	}

	function getTotal()
	{
		return $this->_total;
	}

	function getPagination()
	{
		$this->_loadData() ;

		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');

			$limitstart = $this->getState('limitstart');
			$limit = $this->getState('limit');
			$total = $this->getTotal();

			$this->_pagination = new JPagination( $total, $limitstart, $limit );
		}

		return $this->_pagination;
	}

	function getListMyApplication($member_id)
	{
		//global $mainframe;
		//$db=&JFactory::getDBO();
		$query="select m.*,v.title, c.prefix_name, c.full_name, c.office_phone from #__members_has_application as m, #__vacancy as v, #__consultants as c
		where m.vacancy_id = v.vacancy_id and v.consultant_id=c.consultant_id and member_id=$member_id and DATEDIFF(curdate(), m.applied_date)<93;"; //< 3 months
		$this->_db->setQuery($query);
		$rows = $this->_db->loadObjectList();
		return $rows;
	}

	function removeMyApplication($id, $member_id)
	{
		//$id		= JRequest::getVar('id', 0, '', 'int');
		if($id>0){
			$query=" DELETE FROM #__members_has_application WHERE id=$id AND member_id=$member_id";
			$this->_db->setQuery($query);
			if (!$this->_db->query()) {
				$this->setError( $row->getErrorMsg() );
			}
			return true;
		}else{
			return false;
		}
		//echo $id;
	}
}
