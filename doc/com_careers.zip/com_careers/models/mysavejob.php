<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.model');

class CareersModelMysavejob extends JModel
{
	var $_data = array();
	var $_total = null;
	var $_pagination = null;

	function __construct()
	{
		parent::__construct();

		$application = JFactory::getApplication() ;

		$config = JFactory::getConfig() ;

		$limitstart = JRequest::getInt( 'limitstart', 0 );
		$limit = $application->getUserStateFromRequest( 'global.list.limit', 'limit', $config->getValue('config.list_limit'), 'int' );
		//$limit =2;

		$this->setState('limitstart', $limitstart);
		$this->setState('limit', $limit);
	}

	function _loadData(){
		$session =& JFactory::getSession();
		$member_id = $session->get('member_id');

		if (empty($this->_data) && empty($this->_total)){
				
			if($member_id)
			$query="select m.*,v.* from #__members_has_saved_jobs as m, vip_vacancy as v
			where m.vacancy_id = v.vacancy_id and member_id=$member_id;";
			else
			$query = '';
				
			$this->_db->setQuery($query);
			$this->_data = $this->_db->loadObjectList();
			$this->_total = count( $this->_data ) ;
		}
		return $this->_data ;
	}

	function getData()
	{
		$this->_loadData() ;
		$limitstart = $this->getState('limitstart');
		$limit = $this->getState('limit');

		return array_slice( $this->_data, $limitstart, $limit );
	}

	function getTotal()
	{
		return $this->_total;
	}

	function getPagination()
	{
		$this->_loadData() ;

		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');

			$limitstart = $this->getState('limitstart');
			$limit = $this->getState('limit');
			$total = $this->getTotal();

			$this->_pagination = new JPagination( $total, $limitstart, $limit );
		}

		return $this->_pagination;
	}

	function getListMySaveJob($member_id='')
	{
		$query="select m.*,v.* from #__members_has_saved_jobs as m, vip_vacancy as v
		where m.vacancy_id = v.vacancy_id and member_id=$member_id;";
		$this->_db->setQuery($query);
		$rows = $this->_db->loadObjectList();

		return $rows;
	}

	function removeMySaveJob($id, $member_id)
	{
		if($id>0){
			$query=" DELETE FROM #__members_has_saved_jobs WHERE id=$id AND member_id=$member_id"; //
			$this->_db->setQuery($query);
			if (!$this->_db->query()) {
				$this->setError( $row->getErrorMsg() );
			}
			return true;
		}else{
			return false;
		}
	}

	function getvacancyHasLocation($vacancy_id=1)
	{
		$query="Select c.name from #__vacancy_has_location as v, #__city_lookup as c
		where v.city_id=c.city_id and v.vacancy_id=$vacancy_id;";
		$this->_db->setQuery($query);
		$rows = $this->_db->loadObject();
		return $rows;
	}

	function saveJob($member_id=2, $vacancy_id=1)
	{
		$query='INSERT INTO #__members_has_saved_jobs (member_id, vacancy_id) VALUES ('.$member_id.', '.$vacancy_id.');';
		$this->_db->setQuery($query);

		if (!$this->_db->query()) {
			JError::raiseError( 500, $this->_db->stderr());
		}
	}

	function checkMySaveJob($member_id=2, $vacancy_id=1)
	{
		$query="Select * FROM #__members_has_saved_jobs WHERE member_id=$member_id and vacancy_id=$vacancy_id;";
		$this->_db->setQuery($query);
		$rows = $this->_db->loadObject();
		return count($rows);
	}


}
