<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );
jimport( 'joomla.application.component.helper' );

/**
 * @package		Joomla
 * @subpackage	Banners
 */
class CareersModelCareer extends JModel
{

}	
	