<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class HTML_careers
{
	
	function newsletter()
	{
?>		
		<script language="javascript" type="text/javascript">
	
		function submitbutton(pressbutton) {
			submitform( pressbutton );
		}
		function exportNewletter()
		{
			document.adminForm.target="_blank";
			document.adminForm.task.value="exportNewletterForm";
		}
		</script>
		<form action="index.php" method="post" name="adminForm">
		<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2" height="30"><strong>Generate Job Inform Newsletter</strong></td>
  </tr>
  <tr>
    <td width="15%" valign="top"><strong>ID Jobs:</strong>
ID seperate by comma </td>
    <td width="85%"><textarea name="jobid" cols="80" rows="8"></textarea></td>
  </tr>
  <tr>
	  <td height="30"></td>
	  <td><input type="submit" name="Generate" value="Generate" onClick="exportNewletter();"></td>
  </tr>
</table>

			
			<input type="hidden" name="option" value="com_careers">
			<input type="hidden" name="task" value="">
		</form>				
<?php	
	}
	function vacancy($data)
	{
?>
		<script language="javascript" type="text/javascript">
	
		function submitbutton(pressbutton) {
			submitform( pressbutton );
		}
		
		</script>
		<form action="index.php" method="post" name="adminForm">
			<table width="100%"  border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td height="25" align="center"><strong>Consultant</strong></td>
    <td align="center"><strong>Company</strong></td>
    <td align="center"><strong>Job title</strong></td>
    <td align="center"><strong>ID</strong></td>
    <td align="center"><strong>UID</strong></td>
    <td align="center"><strong>Category</strong></td>
    <td align="center"><strong>Location</strong></td>
    <td align="center"><strong>Min</strong></td>
    <td align="center"><strong>Max</strong></td>
    <td align="center"><strong>View</strong></td>
    <td align="center"><strong>Apply</strong></td>
    <td align="center"><strong>Date Posted</strong></td>
  </tr>
  <?php echo $data; ?>
</table>
			<input type="hidden" name="option" value="com_careers">
			<input type="hidden" name="task" value="">
		</form>
		
<?php 
	}
	function exNewsletter($group)
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>VIPSearch - Nesletter</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

a:link {
	color: #990000;
	text-decoration: none;
}
a:visited {
	color: #990000;
	text-decoration: none;
}
a:active {
	color: #990000;
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #3366CC;
}
-->
</style>
</head>

<body>

<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" bgcolor="#f2f2f2" style="padding:10px 10px 10px 10px"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top"><table width="100%" border="0" align="right" cellpadding="0" cellspacing="0">
              <tr>
                <td width="40%" height="110" style="font-size:24px; font-family:Arial, Helvetica, sans-serif; padding-left:5px"><div align="left"><img src="http://www.vipdatabase.com/newsletter/vipsearch_logo.gif" alt="VIPdatabase.com" width="232" height="106" align="absmiddle"></div></td>
                <td width="30%" height="110" colspan="2" valign="middle" style="font-size:24px; font-family:Arial, Helvetica, sans-serif; padding-left:5px"><div align="right"><font size="5" face="Arial, Helvetica, sans-serif">HOT
                      JOBS</font>  <font color="#666666" size="3"><?php echo date("M d, Y");?></font></div></td>
              </tr>
              <tr>
                <td height="6" colspan="3" bgcolor="#da251d"></td>
              </tr>
              <tr>
                <td height="2" colspan="3" bgcolor="#cccccc"></td>
              </tr>
              <tr valign="top">
                <td height="131" colspan="3" style="padding:0px 0px 0px 0px"><div align="center"><span class="bodytext"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font
color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000"
size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial,
Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font
color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000"
size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#000000" size="2" face="Arial,
Helvetica, sans-serif"><strong><a href="http://www.vipdatabase.com/?act=viewjob&jobid=7250" target="_blank"><img
src="http://www.vipdatabase.com/newsletter/ad_74.jpg" alt="Innovation Manager" width="630" height="130"
border="0"></a></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></strong></font></span></div></td>
              </tr>
              <tr valign="top">
                <td width="70%" colspan="2" style="padding:10px 10px 10px 15px"><p class="bodytext"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Below are positions
                          that we are
                          
                          recruiting
                          on behalf
                          of our clients.
                          To view company
                          info and
                          job description,
                          click on
                      the job title. </font></p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Finance &amp; Accounting</font></font></span></span> </strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[0]; ?>
					  </td>
                    </tr>
                  </table>                  
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Marketing,
                            Brand, Advertising</font></font></span></span> </strong> </td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[1]; ?>
					  </td>
                    </tr>
                  </table>                  
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Sales,
                            Customer Service</font></font></span></span> </strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[2]; ?>
					  </td>
                    </tr>
                  </table>                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">GM,
                            Legal, HR, Admin &amp; Training</font></font></span></span></strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[3]; ?>
					  </td>
                    </tr>
                  </table>                  
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Information Technology</font></font></span></span></strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[4]; ?>
					  </td>
                    </tr>
                  </table>
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Production</font></font></span></span></strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[5]; ?>
					  </td>
                    </tr>
                  </table>                  
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Engineering</font></font></span></span></strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[6]; ?>
					  </td>
                    </tr>
                  </table>                  
                  <p>&nbsp;</p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="22" height="22" align="center" bgcolor="#DA251D"><span style="font-size:14px; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF"><strong>-</strong></span></td>
                      <td bgcolor="#f2f2f2" style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px"><strong> <span class="bodytext_sal"><span class="header"><font color="#00CC00" size="4" face="Arial, Helvetica, sans-serif"><font color="#000000">Others</font></font></span></span></strong></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="font-size:12px; font-family:Arial, Helvetica, sans-serif; padding-left:10px">
					  <?php echo $group[7]; ?>
					  </td>
                    </tr>
                  </table>                  <p>&nbsp;</p>
                  <p><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">To
                        view all
                        job listings,<span class="bodytext_sal"> <a href="http://www.vipdatabase.com/index.php?act=searchresults&typesearch=1" target="_blank">click
                        here</a></span> &raquo;<span class="bodytext_sal">.</span></font></p></td>
                <td width="30%" valign="top" bgcolor="#F7F7F7" style="padding:10px 10px 10px 15px"><p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <table width="80%"  border="0" align="center">
                    <tr>
                      <td><p style="padding:5px 0px 5px 0px "><font color="#000000" size="3" face="Arial, Helvetica, sans-serif"><span class="bodytext_sal style1 style2"><strong>Submit Your Resume</strong></span></font></p>
                        <p><font color="#333333" size="2" face="Arial, Helvetica, sans-serif"><span class="bodytext_sal style1 style2"><strong></strong>We invite anyone who would like to pursue better career development to send resume to us at the following email address. Your resume will be kept strictly confidential. If there is a good opportunity that matches your background, we will let you know before forwarding your profile to any third parties.</span></font></p>
                        <p style="padding:5px 0px 5px 0px " class="style3"><font color="#333333" size="2" face="Arial, Helvetica, sans-serif">Please send your resume (preferably inMS Word format) to <strong><font color="#990000">resume@vipsearch.com</font></strong></font></p></td>
                    </tr>
                  </table>                  <p align="center">&nbsp;</p>
                  </td>
              </tr>
            </table></td>
          </tr>
        </table>          </td>
      </tr>
      <tr>
        <td height="2" bgcolor="#da251d"></td>
      </tr>
    </table>
      <p align="center" style="padding:5px 0px 5px 0px  class="bodytextaddress" ><font color="#999999" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#990000">VIPSearch - A Division of NVM Group </font></strong><font color="#666666"><br>
        <font size="1">Add:
                        Floor 7,
                        Vietnam
                        Economic
                        Times Building,
                        1/1 Hoang
                        Viet, W.4,
                        Tan Binh
                        Dist.,
                        HCMC<br>
  Tel: +848 38 117 900 | Website:
  www.vipsearch.com</font></font></font></p>
      <p align="center" style="padding:5px 0px 5px 0px  class="bodytextaddress" ><font color="#990000" size="2" face="Arial, Helvetica, sans-serif"><strong>A
            Glasford International<font size="2" face="Arial, Helvetica, sans-serif">&reg;</font> Partner</strong></font><font size="2" face="Arial, Helvetica, sans-serif"> (www.glasford.com)</font></p>
      <p align="center" style="padding:5px 0px 5px 0px  class="bodytextaddress" ><font size="2" face="Arial, Helvetica, sans-serif">To
          unsubscribe or change
          your profile: <A href="{{user("unsubaddr")}}">click
          here</A>.<BR>
  To subscribe: <A href="{{user("subaddr")}}">click
  here</A>. </font></p>      </td>
  </tr>
</table>

</body>
</html>

<?php
	}
}
?>	