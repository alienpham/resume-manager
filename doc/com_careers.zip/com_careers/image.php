<?php
require_once('../../configuration.php');
$conf = new JConfig();

$DB_HOST = $conf->host;
$DB_USER = $conf->user;;
$DB_PASSWORD = $conf->password;
$DB_NAME = $conf->db;

$conn = mysql_connect ($DB_HOST, $DB_USER, $DB_PASSWORD);
if (!$conn) {
	die('Could not connect: ' . mysql_error());
}
//echo 'Connected successfully';
mysql_select_db ($DB_NAME);

function getImage($vacancy_id=1){
	$data ='';
	$select_sql="SELECT c.* FROM vip_company_profile c, vip_vacancy v
	WHERE c.company_profile_id=v.company_profile_id AND v.vacancy_id=$vacancy_id;";
	//echo $select_sql;
	$result = @ mysql_query($select_sql);

	while($row = @ mysql_fetch_array($result)){
		$data= $row['logo_content'];
	}
	return $data;
}


//$vacancy_id = $HTTP_GET_VARS["vacancy_id"];
$vacancy_id = $_GET["vacancy_id"];
mysql_close($link);

ob_end_clean();
header("Content-Type: image/gif");

//call
echo getImage($vacancy_id);

?>