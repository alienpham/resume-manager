<?php
require_once('../../configuration.php');
$conf = new JConfig();

$DB_HOST = $conf->host;
$DB_USER = $conf->user;;
$DB_PASSWORD = $conf->password;
$DB_NAME = $conf->db;

$conn = mysql_connect ($DB_HOST, $DB_USER, $DB_PASSWORD);
if (!$conn) {
	die('Could not connect: ' . mysql_error());
}
//echo 'Connected successfully';
mysql_select_db ($DB_NAME);
mysql_set_charset('utf8', $conn);

$user_id = @$_REQUEST['user_id'];
$public_profile_id = @$_REQUEST['public_profile_id'];
$vacancy_id = @$_REQUEST['vacancy_id'];

$GLOBALS['HTTP_RAW_POST_DATA'] = file_get_contents("php://input");
$xmlstr = $HTTP_RAW_POST_DATA;

$xml = '';
$xmls = <<<XML
$xmlstr
XML;
$xml =new SimpleXMLElement($xmls);

//vip_consultants
if($user_id)
foreach ($xml->xpath('//txml') as $vip_consultants) {
	//print_r($vip_consultants); exit;
	foreach($vip_consultants as $vip_consultant){
		$action = $vip_consultant->sync_action;
		switch ($action) {
			case 'Add': { add_table('vip_consultants',$vip_consultant); break;}
			case 'Edit': { update_table('vip_consultants',$vip_consultant); break;}
			case 'Delete': { update_table('vip_consultants',$vip_consultant); break;}
		}
	}
}

//vip_company_profile
if($public_profile_id)
foreach ($xml->xpath('//txml') as $vip_company_profiles) {
	foreach($vip_company_profiles as $vip_company_profile){
		$action = $vip_company_profile->sync_action;
		switch ($action) {
			case 'Add': { add_table('vip_company_profile',$vip_company_profile); break;}
			case 'Edit': { update_table('vip_company_profile',$vip_company_profile); break;}
			case 'Delete': { update_table('vip_company_profile',$vip_company_profile);
			//delete_table('vip_company_profile',$vip_company_profile);
			break;}
		}
	}
}



//vip_vacancy
if($vacancy_id)
foreach ($xml->xpath('//txml') as $vip_vacancys) {
	foreach($vip_vacancys as $vip_vacancy){
		$action = $vip_vacancy->sync_action;
		switch ($action) {
			case 'Add': {
				add_table('vip_vacancy',$vip_vacancy);
				set_vip_vacancy_has('vip_vacancy_has_function',$vip_vacancy);
				set_vip_vacancy_has('vip_vacancy_has_location',$vip_vacancy);
				break;
			}
			case 'Close':
			case 'Edit': {
				update_table('vip_vacancy',$vip_vacancy);
				set_vip_vacancy_has('vip_vacancy_has_function',$vip_vacancy);
				set_vip_vacancy_has('vip_vacancy_has_location',$vip_vacancy);
				break;
			}
			case 'Delete': {
				set_vip_vacancy_has('vip_vacancy_has_function',$vip_vacancy);
				set_vip_vacancy_has('vip_vacancy_has_location',$vip_vacancy);
				update_table('vip_vacancy',$vip_vacancy);
				//delete_table('vip_vacancy',$vip_vacancy);
				break;
			}
		}
	}
}


//Add
function add_table($table_name, $table_object){
	//$data ='';
	$result = FALSE;
	$data='';

	if($table_name == 'vip_company_profile'){
		$select_sql= "INSERT INTO `vip_company_profile`
				SET `company_profile_id`='".$table_object['id']."',
				`display_company_name`=".parseNull(base64_decode($table_object->display_company_name)).",
				`introduction`=".parseNull(base64_decode($table_object->introduction)).",
				`display_website`=".parseNull($table_object->display_website).",
				`status`='".$table_object->status."',
				`logo_name`=".parseNull(base64_decode($table_object->logo_name)).",
				`logo_file_type`=".parseNull($table_object->logo_file_type).",
				`logo_file_size`=".parseNull($table_object->logo_file_size).",
				`logo_content`=".parseNull(base64_decode($table_object->logo_content)).",
				`logo_width`=".parseNull($table_object->logo_width).",
				`logo_height`=".parseNull($table_object->logo_height).";";
	}

	if($table_name == 'vip_consultants')
	$select_sql= "INSERT INTO `vip_consultants`
				SET `consultant_id`='".$table_object['id']."',
				`prefix_name`=".parseNull(conver_prefix_name($table_object->gender_id)).",
				`email`=".parseNull($table_object->email).",
				`full_name`=".parseNull(base64_decode($table_object->full_name)).",
				`mobile`=".parseNull($table_object->mobile).",
				`status`='".user_status_lookup($table_object->user_status_id)."',
				`office_phone`=".parseNull($table_object->office_phone).";";

	if($table_name == 'vip_vacancy')
	$select_sql= "INSERT INTO `vip_vacancy`
				SET `vacancy_id`='".$table_object['id']."',
				`vacancy_code`=".parseNull($table_object->vacancy_code).",
				`vacancy_type_id`=".parseNull($table_object->vacancy_type_id).",
				`work_level_id`=".parseNull($table_object->work_level_id).",
				`consultant_id`=".parseNull($table_object->user_id).",
				`company_profile_id`=".parseNull($table_object->public_profile_id).",
				`title`=".parseNull(base64_decode($table_object->title)).",
				`salary_min`=".parseNull($table_object->salary_min).",
				`salary_max`=".parseNull($table_object->salary_max).",
				`description`=".parseNull(base64_decode($table_object->description)).",
				`requirement`=".parseNull(base64_decode($table_object->requirement)).",
				`vacancy_status`=".parseNull(vacancy_status_lookup($table_object->vacancy_status_id)).",
				`posted_date`=".parseNull($table_object->posted_date).",
				`closed_date`=".parseNull($table_object->closed_date).";";


	//echo $select_sql;
	$result = mysql_query($select_sql);
	if (!$result) {
		$data ="\n\t SQL Erorr:". mysql_error();
		$data .= "\n\t".$select_sql;
	}else{
		$data='true';
	}

	//@mysql_free_result($result);
	//$data = $select_sql;
	echo $data;
}


//Update
function update_table($table_name, $table_object){
	//$data ='';
	$data='';

	if($table_name == 'vip_company_profile'){
		$logo_file_size = $table_object->logo_file_size;
		$logo_width = $table_object->logo_width;
		$logo_height = $table_object->logo_height;

		if(!$logo_file_size) $logo_file_size = NULL;
		if(!$logo_width) $logo_width = NULL;
		if(!$logo_height) $logo_height = NULL;

		$select_sql= "UPDATE `vip_company_profile`
				SET
				`display_company_name`=".parseNull(base64_decode($table_object->display_company_name)).",
				`introduction`=".parseNull(base64_decode($table_object->introduction)).",
				`display_website`=".parseNull($table_object->display_website).",
				`status`='".$table_object->status."',
				`logo_name`=".parseNull(base64_decode($table_object->logo_name)).",
				`logo_file_type`=".parseNull($table_object->logo_file_type).",
				`logo_file_size`=".parseNull($table_object->logo_file_size).",
				`logo_content`=".parseNull(base64_decode($table_object->logo_content)).",
				`logo_width`=".parseNull($table_object->logo_width).",
				`logo_height`=".parseNull($table_object->logo_height)."
				WHERE `company_profile_id`='".$table_object['id']."';";
	}

	if($table_name == 'vip_consultants')
	$select_sql= "UPDATE `vip_consultants`
				SET
				`prefix_name`=".parseNull(conver_prefix_name($table_object->gender_id)).",
				`email`=".parseNull($table_object->email).",
				`full_name`=".parseNull(base64_decode($table_object->full_name)).",
				`mobile`=".parseNull($table_object->mobile).",
				`office_phone`=".parseNull($table_object->office_phone).",
				`status`='".user_status_lookup($table_object->user_status_id)."'
				WHERE `consultant_id`='".$table_object['id']."';";

	if($table_name == 'vip_vacancy')
	$select_sql= "UPDATE `vip_vacancy`
				SET
				`vacancy_code`=".parseNull($table_object->vacancy_code).",
				`vacancy_type_id`=".parseNull($table_object->vacancy_type_id).",
				`work_level_id`=".parseNull($table_object->work_level_id).",
				`consultant_id`=".parseNull($table_object->user_id).",
				`company_profile_id`=".parseNull($table_object->public_profile_id).",
				`title`=".parseNull(base64_decode($table_object->title)).",
				`salary_min`=".parseNull($table_object->salary_min).",
				`salary_max`=".parseNull($table_object->salary_max).",
				`description`=".parseNull(base64_decode($table_object->description)).",
				`requirement`=".parseNull(base64_decode($table_object->requirement)).",
				`vacancy_status`=".parseNull(vacancy_status_lookup($table_object->vacancy_status_id)).",
				`posted_date`=".parseNull($table_object->posted_date).",
				`closed_date`=".parseNull($table_object->closed_date)."
			WHERE `vacancy_id`='".$table_object['id']."';";

	//echo $select_sql; exit;

	$result = mysql_query($select_sql);
	if (!$result) {
		//die('Invalid query: ' . mysql_error());
		$data = "\n\t SQL Erorr:". mysql_error();
		$data .= "\n\t".$select_sql;
	}else{
		$data='true';
	}

	/*try {
	 mysql_query($select_sql);
	 }catch(Exception $e) {
	 $data='Update record '.$table_object['id'].' to database has error!';
	 //$data = $e->getMessage();
	 //continue;
	 }*/
	//@mysql_free_result($result);
	echo $data;
}


//Delete
function delete_table($table_name, $table_object){
	//$data ='';
	$data='';

	if($table_name == 'vip_company_profile')
	$select_sql= "DELETE FROM `vip_company_profile`	WHERE `company_profile_id`='".$table_object['id']."';";

	if($table_name == 'vip_consultants')
	$select_sql= "DELETE FROM `vip_consultants`	WHERE `consultant_id`='".$table_object['id']."';";

	if($table_name == 'vip_vacancy')
	$select_sql= "DELETE FROM `vip_vacancy`	WHERE `vacancy_id`='".$table_object['id']."';";

	if($table_name == 'vip_vacancy_has_function')
	$select_sql= "DELETE FROM `vip_vacancy_has_function` WHERE `vacancy_id`='".$table_object['id']."';";

	if($table_name == 'vip_vacancy_has_location')
	$select_sql= "DELETE FROM `vip_vacancy_has_location` WHERE `vacancy_id`='".$table_object['id']."';";


	//echo $select_sql; exit;

	$result = mysql_query($select_sql);
	if (!$result) {
		//die('Invalid query: ' . mysql_error());
		$data ="\n SQL Erorr:". mysql_error();
		$data .= "\n".$select_sql;
	}else{
		$data='true';
	}

	/*	try {
	 mysql_query($select_sql);
	 }catch(Exception $e) {
	 $data='Delete record '.$table_object['id'].' to database has error!';
	 //$data = $e->getMessage();
	 //continue;
	 }*/

	echo $data;
}


function set_vip_vacancy_has($table_name, $table_object){
	$data ='';

	if($table_name == 'vip_vacancy_has_location' && $table_object->list_location){
		//delete
		delete_table($table_name, $table_object);

		//insert
		$lists = explode(',', $table_object->list_location);
		if(count($lists))
		foreach($lists as $city_id){
			$select_sql= "INSERT INTO `vip_vacancy_has_location`
				SET `city_id`='".$city_id."',
				`vacancy_id`='".$table_object['id']."';";
			try {
				$result = @ mysql_query($select_sql);
				//$data='true';
			}catch(Exception $e) {
				//$data='fail';
				//echo $e->getMessage();
				//continue;
			}
		}
	}

	if($table_name == 'vip_vacancy_has_function' && $table_object->list_function){
		//delete
		delete_table($table_name, $table_object);

		$lists = explode(',', $table_object->list_function);
		if(count($lists))
		foreach($lists as $function_id){
			$select_sql= "INSERT INTO `vip_vacancy_has_function`
				SET `vacancy_id`='".$table_object['id']."',
				`function_id`='".$function_id."';";
			try {
				$result = @ mysql_query($select_sql);
				//$data='true';
			}catch(Exception $e) {
				//$data='fail';
				//echo $e->getMessage();
				//continue;
			}
		}
	}
	//$data = $select_sql;
	//echo $data;
}


function conver_prefix_name($prefix_name){
	$data = '';
	switch ($prefix_name) {
		case 1:
			$data = 'Mr.';	break;
		case 2:
			$data = 'Ms.';	break;
	}
	return $data;
}

function vacancy_status_lookup($vacancy_status_id){
	$data = '';
	switch ($vacancy_status_id) {
		case 1:
			$data = 'Active Public';	break;
		case 4:
			$data = 'Closed';	break;
		case 5:
			$data = 'Deleted';	break;
		default: $data = 'Active Public';	break;
	}
	return $data;
}

function user_status_lookup($user_status_id){
	$data = '';
	switch ($user_status_id) {
		case 1:
			$data = 'Active';	break;
		case 2:
			$data = 'Inactive';	break;
		default: $data = 'Active';	break;
	}
	return $data;
}

function parseNull($data)
{
	// Be sure your data is escaped before you use this function
	if (chop($data) != ""){
		if (strtolower(chop($data)) == "null"){
			return "NULL";
		}else{
			return "'" . mysql_escape_string($data) . "'";
		}
	}else{
		return "NULL";
	}
}

mysql_close($conn);
