<?php
require_once('../../configuration.php');
$conf = new JConfig();

$DB_HOST = $conf->host;
$DB_USER = $conf->user;;
$DB_PASSWORD = $conf->password;
$DB_NAME = $conf->db;

$conn = mysql_connect ($DB_HOST, $DB_USER, $DB_PASSWORD);
if (!$conn) {
	die('Could not connect: ' . mysql_error());
}
//echo 'Connected successfully';
mysql_select_db ($DB_NAME);
mysql_set_charset('utf8', $conn);

$lastupdate = @$_REQUEST['lastupdate']; //last update resume
$id = @$_REQUEST['id']; //id resume
$select = @$_REQUEST['select']; //select resume or jobseeker
$list = @$_REQUEST['list']; //get list resume

//lastupdate = curdate() - INTERVAL 3 DAY and
//get list resume

header("Content-type: text/xml");
$xml_version = '<?xml version="1.0" standalone="yes"?>'."\n";
$xml_resume = '<resumes>'."\n";
$xml_list ='<list>'."\n";

//echo $lastupdate; exit;
if($lastupdate){
	//$list_resume = '';
	if(($lastupdate != NULL) && ($lastupdate != "")){
		$sql = 'SELECT * FROM vip_resume WHERE updated_date>='."'".$lastupdate."'";
		//echo $sql; exit;
		$result = mysql_query($sql);

		while ($resume_r = mysql_fetch_array($result, MYSQL_ASSOC)){
			$xml_list .= '<id>'.$resume_r['resume_id'].'</id>'."\n";
			$xml_list .= '<updated_date>'.$resume_r['updated_date'].'</updated_date>'."\n";
			$xml_list .= '<created_date>'.$resume_r['created_date'].'</created_date>'."\n";
		}
		@mysql_free_result($result);
	}
	$xml_list .='</list>'."\n";
	echo $xml_list;
	exit;
}

if($id){
	//$sql = 'SELECT * FROM vip_resume r WHERE r.resume_id='."'".$resume_id."'";
	$sql = "SELECT r.*, m.prefix_name, m.full_name, m.email, m.activation  FROM vip_resume as r INNER JOIN vip_members as m ON r.member_id=m.member_id WHERE r.resume_id='".$id."'";
	//echo $sql;
	$result = mysql_query($sql);
	$resume_r = mysql_fetch_array($result, MYSQL_ASSOC);
	if ($resume_r){
		$xml_resume .= '<resume id="'.$resume_r['resume_id'].'">'."\n";
		$xml_resume .= '<member_id>'.$resume_r['member_id'].'</member_id>'."\n";
		$xml_resume .= '<name>'.$resume_r['name'].'</name>'."\n";
		$xml_resume .= '<file_type>'.$resume_r['file_type'].'</file_type>'."\n";
		$xml_resume .= '<file_size>'.$resume_r['file_size'].'</file_size>'."\n";
		$xml_resume .= '<file_content>'.base64_encode($resume_r['file_content']).'</file_content>'."\n";
		$xml_resume .= '<created_date>'.$resume_r['created_date'].'</created_date>'."\n";
		$xml_resume .= '<updated_date>'.$resume_r['updated_date'].'</updated_date>'."\n";
		$xml_resume .= '<prefix_name>'.$resume_r['prefix_name'].'</prefix_name>'."\n";
		$xml_resume .= '<full_name>'.$resume_r['full_name'].'</full_name>'."\n";
		$xml_resume .= '<email>'.$resume_r['email'].'</email>'."\n";
		$xml_resume .= '<vip_members_has_function>'. get_vip_members_has_function($resume_r['member_id']) .'</vip_members_has_function>'."\n";
		$xml_resume .= '</resume>'."\n";
	}
	$xml_resume .= '</resumes>'."\n";
	@mysql_free_result($resume_r);
	echo $xml_resume;
}

function get_vip_members_has_function($member_id){
	$list ='';
	$sql = "SELECT * FROM vip_members_has_function WHERE member_id='".$member_id."'";
	$result = mysql_query($sql);

	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$list.= $row['function_id'].',';
	}

	$list = rtrim($list,',');

	@mysql_free_result($resume_r);
	return $list;
}


?>