<?php 
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

require_once( JApplicationHelper::getPath( 'admin_html' ) );

$task 	= JRequest::getVar('task', '' ,"REQUEST");

switch ($task)
{
	case 'exportNewletter':
		exportNewletter();
		break;

	case 'exportVacancy':
		exportVacancy();
		break;
	
	case 'exportNewletterForm':
		exportNewletterForm();
		break;	
	
	default:
		display();
		break;
}


function display(){
	
	HTML_Careers::newsletter();
}

function exportNewletter(){
	global $mainframe;
	HTML_Careers::newsletter();
}

function exportNewletterForm(){
	global $mainframe;
	$listJobId = JRequest::getVar("jobid");
	$group= array();
	if($listJobId=="")
		$listJobId="''";
	$group[0]=getDataJobInform($listJobId,"2,3,4,5,6,7,8,9,10,11,12,13,14,15,16");
	$group[1]=getDataJobInform($listJobId,"39,40,41,42,45,46,47,48,49,50,105,106,107,108,109,110,111,112,113,114,115");
	$group[2]=getDataJobInform($listJobId,"123,124,125,126,127,128,129,130,131,132,133");
	$group[3]=getDataJobInform($listJobId,"18,19,20,21,22,23,24,34,35,36,37,65,66,67,68,69,70,71,72,86,87,88,89,90");
	$group[4]=getDataJobInform($listJobId,"74,75,76,77,78,79,80,81,82,83,84");
	$group[5]=getDataJobInform($listJobId,"92,93,94,95,96,97,98,100,101,102,103,117,118,119,120");
	$group[6]=getDataJobInform($listJobId,"26,27,28,29,30,31,32,52,53,54,55,56,57,58,59,60,61,62,63");
	$group[7]=getDataJobInform($listJobId,"135");
	HTML_Careers::exNewsletter($group);
	exit;
}

function exportVacancy(){
	global $mainframe;
	//echo "exportVacancy";
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header("Content-Disposition: attachment; filename=exportVacancy_[".date('d-M-Y')."].xls");
	header("Pragma: no-cache");
	header("Expires: 0");	
	$data=exportJobList();
	HTML_Careers::vacancy($data);
	exit;
}

function exportJobList()
{
	$data="";
  
	$db =& JFactory::getDBO();
	$query="SELECT DISTINCT vacancy_id, consultant_id, company_profile_id, posted_date, title, salary_min, salary_max, view_count FROM #__vacancy WHERE vacancy_status = 'Active Public'";
	$db->setQuery($query);
	$rows = $db->loadObjectList();
	foreach($rows as $row)
	{
		$company = getListName("#__company_profile","company_profile_id= '$row->company_profile_id'","display_company_name");
		$consultant = getListName("#__consultants","consultant_id= '$row->consultant_id'","prefix_name")." ". getListName("#__consultants","consultant_id= '$row->consultant_id'","full_name");
		$location_id = str_replace("|",",",getListName("#__vacancy_has_location", "vacancy_id='".$row->vacancy_id."'","city_id"));
		if ($location_id=="")
			$location_id="''";
		$location = getListName("#__city_lookup", "city_id in(".$location_id.")","name");
		$function_id = str_replace("|",",",getListName("#__vacancy_has_function", "vacancy_id='".$row->vacancy_id."'","function_id"));
		if($function_id=="")
			$function_id="''";
		$function_id= str_replace("|",",",getListName("#__function_lookup", "function_id in(".$function_id.")","parent_function_id"));
		if($function_id=="")
			$function_id="''";
		$category = getListName("#__function_lookup", "function_id in(".$function_id.")","name");	
		$query = "SELECT count(id) as numapply FROM #__members_has_application WHERE vacancy_id = '$row->vacancy_id'";
		$db->setQuery($query);
		$rsapply = $db->loadObject();
		$apply=$rsapply->numapply;
		$data.="<tr>
			    <td height=\"25\">$consultant</td>
			    <td>$company</td>
			    <td>$row->title</td>
			    <td>$row->vacancy_id</td>
			    <td>$row->consultant_id</td>
			    <td>$category</td>
			    <td>$location</td>
			    <td>$row->salary_min</td>
			    <td>$row->salary_max</td>
			    <td>$row->view_count</td>
			    <td>$apply</td>
			    <td>".date("M-d-Y",strtotime($row->posted_date))."</td>
			  </tr>";
	}
	return $data;
}

function getDataJobInform($listJobId,$groupFunction)
{
	$db =& JFactory::getDBO();
	$query="SELECT DISTINCT a.vacancy_id, a.title, a.salary_min, a.salary_max FROM #__vacancy a, #__vacancy_has_function b WHERE a.vacancy_id in ($listJobId) AND a.vacancy_id=b.vacancy_id AND b.function_id in($groupFunction)";
	$db->setQuery($query);
	$rows = $db->loadObjectList();
	$data="";
	foreach($rows as $row)
	{
		$salary = getSalary($row->salary_min,$row->salary_max);
		$listLocationID = str_replace("|",",",getListName("#__vacancy_has_location", "vacancy_id='".$row->vacancy_id."'","city_id"));
		if($listLocationID=="")
	 		$listLocationID="''";
		$listLocation = getListName("#__city_lookup", "city_id in(".$listLocationID.")","name");
		
		$data.="<p align=\"left\" style=\"padding-top:2px; padding-bottom:2px\"><font color=\"#666666\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"http://vipsearch.com/en/career-opportunities/senior-a-excutive-jobs/detail-senior-a-excutive-jobs/jobdetail/".$row->vacancy_id."\" target=\"_blank\">".$row->title."</a> - $listLocation - $salary</font></p>";
	}
	return $data;
}

function getSalary($min,$max)
{
	if($min==$max && $max>0)
		$salary="Around $".$max;
	else
	if($min==$max && $max==0)
		$salary="Negotiable";
	else
	if($min>0 && $max==0)
		$salary="Above $".$min;
	else			
	if($min==0 && $max>0)
		$salary="Up to $".$max;
	else
		$salary="$".$min. " - $".$max;
	return $salary;
}
function getListName($table,$condition,$field)
{
	$db =& JFactory::getDBO();
	$query = "SELECT distinct($field) as $field FROM $table WHERE $condition ";
	$db->setQuery($query);
	$rows = $db->loadObjectList();
	$num = 0;
	$str = "";
	foreach( $rows as $row )
	{
		if ( $num==0 )
			$str = $row->$field;
		else
			$str.= " | ".$row->$field;
		$num++;
	}
	return $str;
}
	

