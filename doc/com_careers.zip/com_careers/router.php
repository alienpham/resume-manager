<?php
/**
* @version		$Id: router.php 10752 2008-08-23 01:53:31Z eddieajau $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

function CareersBuildRoute(&$query)
{
	$segments = array();

	if(isset($query['view']))
	{
		$segments[] = $query['view'];
		unset($query['view']);
	
	}
	
	if (isset($query['task'])) {
		$segments[] = (isset($query['task']))? $query['task'] : '';
		unset( $query['task'] );
	}	
	
	if (isset($query['id'])) {
		$segments[] = (isset($query['id']))? $query['id'] : '';
		unset( $query['id'] );
	}
	
	if (isset($query['vacancy_id'])) {
		$segments[] = $query['vacancy_id'];
		unset( $query['vacancy_id'] );
	}
	
	return $segments;
}

function CareersParseRoute($segments)
{
	$vars = array();
	$count = count($segments);
//print_r($segments);exit;	
	
	if($segments[0] == 'removemysavejob' || $segments[0] == 'removemyapplication') 
	{
		$vars['task'] = $segments[0];
		$vars['id'] = $segments[1];
	
	}else if($segments[0] == 'sendmail' || $segments[0] == 'viewpdf' || $segments[0] == 'savejob'){
		
		$vars['task'] = $segments[0];
		$vars['vacancy_id'] = $segments[1];
	
	}else{
		
		if(!empty($count)) {
			$vars['view'] = $segments[0];
		}
		
		if($count > 1) {
			$vars['vacancy_id']    = $segments[$count - 1];
		}
	}
	
	return $vars;
}
