<?php
defined('JPATH_BASE') or die();

class JCareer {
	function lookupCityVacancyHasLocation($vacancy_ID){
		global $mainframe;
		$db=&JFactory::getDBO();
		$query=" SELECT DISTINCT c.name FROM vip_vacancy_has_location as v, vip_city_lookup as c
		WHERE v.city_id=c.city_id and v.vacancy_id=$vacancy_ID ";
		$db->setQuery($query);
		$rows = $db->loadObject();
		return $rows->name;
	}

	function getVacancyStatus($vacancy_ID){
		global $mainframe;
		//ENUM('Active Public','Closed','Deleted')
		$db=&JFactory::getDBO();
		$query="SELECT vacancy_status FROM vip_vacancy v WHERE vacancy_id=$vacancy_ID ";
		$db->setQuery($query);
		$rows = $db->loadObject();
		return $rows->vacancy_status;
	}


}

?>